-- Target bar (XIUI style): one long slim bar, the target's name above it on
-- the left and HP% on the right. The target's cast bar sits under it.
-- Not secure: it shows and hides with your target, in or out of combat.
local _, ns = ...

local M = ns.AddModule("TargetBar")

local W, W_COMPACT, H = 390, 300, 16

local function Update(f)
  if not UnitExists("target") then
    f:Hide()
    return
  end
  f:Show()
  ns.Values.Name(f.name, "target")
  ns.Values.Health(f.hp, f.pct, "target", "percent", false)
  local dead = ns.Values.IsDead("target")
  if dead then f.pct:SetText("Dead") end
end

local function Layout(f)
  local w = ns.db.compact and W_COMPACT or W
  f:SetSize(w, H + 18)
  f.hp:SetSize(w, H)
end

function M:Init()
  if ns.db.modules.target then
    local f = CreateFrame("Frame", "ForeverXITargetBar", UIParent)
    f.hp = ns.Style.Bar(f, W, H, "hpTarget")
    f.hp:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 0, 2)
    f.hp:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", 0, 2)

    f.name = ns.Style.Text(f, 13)
    f.name:SetPoint("BOTTOMLEFT", f.hp, "TOPLEFT", 4, 2)
    f.name:SetJustifyH("LEFT")
    f.name:SetWordWrap(false)
    f.pct = ns.Style.Text(f, 12)
    f.pct:SetPoint("BOTTOMRIGHT", f.hp, "TOPRIGHT", -4, 2)
    f.pct:SetJustifyH("RIGHT")
    f.pct:SetTextColor(ns.Style.Color("hpText"))
    f.name:SetPoint("RIGHT", f.pct, "LEFT", -8, 0)
    Layout(f)

    f:RegisterEvent("PLAYER_TARGET_CHANGED")
    f:RegisterEvent("PLAYER_ENTERING_WORLD")
    for _, e in ipairs({ "UNIT_HEALTH", "UNIT_MAXHEALTH", "UNIT_NAME_UPDATE", "UNIT_FLAGS" }) do
      pcall(f.RegisterUnitEvent, f, e, "target")
    end
    f:SetScript("OnEvent", function(self) if not self.previewing then Update(self) end end)
    Update(f)

    self.frame = f
    ns.AddRoot(f)
    ns.Movers.Register("target", "Target bar", f, { "BOTTOM", "BOTTOM", 0, 360 })
  end

  if ns.db.modules.targetCast then
    local c = ns.CastBar.Create("ForeverXITargetCast", "target", 300, 13, true)
    self.cast = c
    ns.AddRoot(c)
    ns.Movers.Register("targetCast", "Target cast bar", c, { "BOTTOM", "BOTTOM", 0, 340 })
  end
end

function M:Relayout()
  if self.frame then Layout(self.frame) end
end

-- /fxi move shows a pretend target so the bar can be placed.
function M:Preview(on)
  local f = self.frame
  if f then
    f.previewing = on and true or nil
    if on then
      f.name:SetText("Target Name")
      f.pct:SetText("62%")
      f.hp:SetMinMaxValues(0, 100)
      f.hp:SetValue(62)
      f:Show()
    else
      Update(f)
    end
  end
  if self.cast then ns.CastBar.Preview(self.cast, on) end
end
