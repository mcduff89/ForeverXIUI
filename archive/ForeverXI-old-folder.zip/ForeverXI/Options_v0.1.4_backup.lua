-- Options in Blizzard's Settings panel (Esc > Options > AddOns > ForeverXI)
-- and the /fxi slash command.
local _, ns = ...

local M = ns.AddModule("Options")

local category

local function Changed(needsReload)
  return function()
    if needsReload then
      ns.Print("change saved. Type /reload to apply it.")
    else
      ns.ApplyScale()
      ns.ForEachModule("Relayout")
    end
  end
end

-- Each option: table, key, label, tooltip, default, needsReload.
local function Checkbox(cat, tbl, key, label, tooltip, needsReload)
  local variable = "ForeverXI_" .. label:gsub("%W", "")
  local setting = Settings.RegisterAddOnSetting(cat, variable, key, tbl, Settings.VarType.Boolean, label,
    tbl[key] and true or false)
  Settings.CreateCheckbox(cat, setting, tooltip)
  setting:SetValueChangedCallback(Changed(needsReload))
end

local function Build()
  local db = ns.db
  local cat = Settings.RegisterVerticalLayoutCategory("ForeverXI")

  local scale = Settings.RegisterAddOnSetting(cat, "ForeverXI_Scale", "scale", db, Settings.VarType.Number,
    "Scale", 1)
  local opts = Settings.CreateSliderOptions(0.6, 1.6, 0.05)
  if MinimalSliderWithSteppersMixin and MinimalSliderWithSteppersMixin.Label then
    opts:SetLabelFormatter(MinimalSliderWithSteppersMixin.Label.Right, function(v) return ("%.2f"):format(v) end)
  end
  Settings.CreateSlider(cat, scale, opts, "Size of every ForeverXI frame.")
  scale:SetValueChangedCallback(Changed(false))

  -- One size slider per frame, multiplied with the global scale.
  local frames = {
    { "player", "Player bar size" }, { "playerCast", "Your cast bar size" },
    { "target", "Target bar size" }, { "targetCast", "Target cast bar size" },
    { "party", "Party list size" }, { "raid", "Raid list size" },
  }
  for _, info in ipairs(frames) do
    local key, label = info[1], info[2]
    local s = Settings.RegisterAddOnSetting(cat, "ForeverXI_Scale_" .. key, key, db.frameScale,
      Settings.VarType.Number, label, 1)
    local o = Settings.CreateSliderOptions(0.5, 2, 0.05)
    if MinimalSliderWithSteppersMixin and MinimalSliderWithSteppersMixin.Label then
      o:SetLabelFormatter(MinimalSliderWithSteppersMixin.Label.Right, function(v) return ("%.2f"):format(v) end)
    end
    Settings.CreateSlider(cat, s, o, "Multiplied with the global scale.")
    s:SetValueChangedCallback(Changed(false))
  end

  Checkbox(cat, db, "compact", "Compact mode", "Narrower bars.", false)

  local m = db.modules
  Checkbox(cat, m, "player", "Player bar", "Your HP and power bars.", true)
  Checkbox(cat, m, "target", "Target bar", "Your target's name and HP.", true)
  Checkbox(cat, m, "playerCast", "Your cast bar", nil, true)
  Checkbox(cat, m, "targetCast", "Target cast bar", "May stay empty on Forever if target casts are hidden from addons.", true)
  Checkbox(cat, m, "party", "Party list", nil, true)
  Checkbox(cat, m, "raid", "Raid list", "Other raid groups, on the right.", true)
  Checkbox(cat, m, "chat", "Chat window skin", "Turning it off needs a /reload.", true)

  Checkbox(cat, db.target, "threatColors", "Threat colours on the target bar",
    "Green safe, yellow careful, red it's on you. As a tank: green you have it, yellow losing it, red lost it.", false)
  Checkbox(cat, db.target, "alwaysTank", "Always use tank threat colours",
    "Otherwise tank colours are used only when your group role is Tank.", false)
  Checkbox(cat, db, "hideBagBar", "Hide Blizzard bag bar", "B and your bag keys still open bags. Turning it back on needs a /reload.", true)
  Checkbox(cat, db, "menuSkin", "XI window behind the menu and bag bar", nil, true)
  Checkbox(cat, db.party, "showSolo", "Show party list when solo", nil, true)
  Checkbox(cat, db.raid, "hideOwnGroup", "Leave my group out of the raid list", "It's already in the party list.", false)

  local h = db.hideBlizzard
  Checkbox(cat, h, "player", "Hide Blizzard player frame", nil, true)
  Checkbox(cat, h, "target", "Hide Blizzard target frame", nil, true)
  Checkbox(cat, h, "cast", "Hide Blizzard cast bar", nil, true)
  Checkbox(cat, h, "party", "Hide Blizzard party frames", nil, true)
  Checkbox(cat, h, "raid", "Hide Blizzard raid frames", "The raid side panel (ready check, markers) stays.", true)

  Settings.RegisterAddOnCategory(cat)
  return cat
end

function M:Init()
  if not (Settings and Settings.RegisterVerticalLayoutCategory and Settings.RegisterAddOnSetting) then
    return
  end
  local ok, cat = pcall(Build)
  if ok then
    category = cat
  else
    ns.Print("the Settings panel didn't build on this client (%s). Use /fxi commands for now.", tostring(cat))
  end
end

local function Help()
  ns.Print("commands:")
  print("  /fxi  - open options")
  print("  /fxi move  - drag frames (also on while Edit Mode is open)")
  print("  /fxi reset  - put every frame back to the default layout")
  print("  /fxi compact  - toggle compact mode")
  print("  /fxi scale 1.2  - size of everything; /fxi scale party 1.1  - one frame")
  print("  /fxi check  - test what Forever lets addons read (run it in combat too)")
end

SLASH_FOREVERXI1 = "/fxi"
SLASH_FOREVERXI2 = "/foreverxi"
SlashCmdList.FOREVERXI = function(msg)
  msg = (msg or ""):lower():match("^%s*(.-)%s*$")
  if msg == "move" or msg == "unlock" or msg == "lock" then
    ns.Movers.Toggle()
  elseif msg == "reset" then
    if InCombatLockdown() then ns.Print("not in combat.") return end
    ns.Movers.ResetAll()
    ns.Print("frames reset to the default layout.")
  elseif msg == "compact" then
    ns.db.compact = not ns.db.compact
    ns.ForEachModule("Relayout")
    ns.Print("compact mode %s.", ns.db.compact and "on" or "off")
  elseif msg:match("^scale") then
    local what, value = msg:match("^scale%s+(%a*)%s*([%d%.]+)$")
    value = tonumber(value)
    if not value or value < 0.3 or value > 3 then
      ns.Print("usage: /fxi scale 1.2  or  /fxi scale party 1.1 (player, playercast, target, targetcast, party, raid)")
      return
    end
    local keys = { player = "player", playercast = "playerCast", target = "target", targetcast = "targetCast", party = "party", raid = "raid" }
    if what == nil or what == "" then
      ns.db.scale = value
    elseif keys[what] then
      ns.db.frameScale[keys[what]] = value
    else
      ns.Print("unknown frame '%s'.", what)
      return
    end
    ns.ApplyScale()
    ns.Print("scale set.")
  elseif msg == "check" then
    ns.Check()
  elseif msg == "help" then
    Help()
  else
    if category and Settings.OpenToCategory then
      local ok = pcall(Settings.OpenToCategory, category:GetID())
      if ok then return end
    end
    Help()
  end
end
