-- Junk by price: a junk rule for Baganator that uses your Auctionator scan.
-- An item counts as junk when selling it on the auction house (after the
-- 5% cut) wouldn't beat the vendor by more than the margin you set. Grey
-- items are always junk. Baganator then shows its junk coin on them and
-- puts them in its Junk section, and its own sell button sells them at a
-- vendor when you click it. Nothing here sells anything by itself.
--
-- Never junk: items that can't be sold to a vendor, items with no
-- Auctionator price (bound gear, things you haven't scanned), epics and up,
-- and (by default) weapons and armour that aren't grey.
local _, ns = ...

local M = ns.AddModule("Junk")

local CALLER = "ForeverXI"
local AH_CUT = 0.95

local function o() return ns.db.junk end

local function SellPrice(itemLink, itemID)
  local get = (C_Item and C_Item.GetItemInfo) or GetItemInfo
  if not get then return end
  local ok, _, _, quality, _, _, _, _, _, _, _, sell, classID = pcall(get, itemLink or itemID)
  if not ok then return end
  return sell, quality, classID
end

local function AuctionPrice(itemLink, itemID)
  local api = Auctionator and Auctionator.API and Auctionator.API.v1
  if not api then return end
  if itemLink and api.GetAuctionPriceByItemLink then
    local ok, p = pcall(api.GetAuctionPriceByItemLink, CALLER, itemLink)
    if ok and type(p) == "number" then return p end
  end
  if itemID and api.GetAuctionPriceByItemID then
    local ok, p = pcall(api.GetAuctionPriceByItemID, CALLER, itemID)
    if ok and type(p) == "number" then return p end
  end
end

local GEAR = { [2] = true, [4] = true }   -- weapon, armour item classes

-- true: junk. Exposed for /fxi check and testing.
function M.IsJunk(itemLink, itemID)
  if o().enabled == false then return false end
  local sell, quality, classID = SellPrice(itemLink, itemID)
  if type(sell) ~= "number" or sell <= 0 then return false end
  if quality == 0 then return true end
  if type(quality) == "number" and quality >= 4 then return false end
  if o().keepGear ~= false and GEAR[classID] then return false end
  local ah = AuctionPrice(itemLink, itemID)
  if not ah then return false end
  local margin = (tonumber(o().margin) or 0) * 100   -- silver to copper
  return ah * AH_CUT <= sell + margin
end

function M.Refresh()
  local api = Baganator and Baganator.API
  if api and api.RequestItemButtonsRefresh then pcall(api.RequestItemButtonsRefresh) end
end

function M:Init()
  local api = Baganator and Baganator.API
  if not (api and api.RegisterJunkPlugin) then return end
  if not (Auctionator and Auctionator.API and Auctionator.API.v1) then return end
  local ok = pcall(api.RegisterJunkPlugin, "ForeverXI: Auctionator price", "foreverxi_price",
    function(_, _, itemID, itemLink)
      local okJ, junk = pcall(M.IsJunk, itemLink, itemID)
      return okJ and junk or false
    end)
  self.active = ok
end

function M:Relayout()
  if self.active then M.Refresh() end
end

function M.Describe()
  if not M.active then return "off (needs Baganator and Auctionator)" end
  local live = Baganator.API.IsJunkPluginActive and Baganator.API.IsJunkPluginActive("foreverxi_price")
  return ("on, margin %ds, %s"):format(tonumber(o().margin) or 0,
    live and "chosen in Baganator" or "not chosen in Baganator yet (Customise > Junk)")
end
