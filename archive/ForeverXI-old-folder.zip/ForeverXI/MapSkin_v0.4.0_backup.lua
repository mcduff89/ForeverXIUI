-- The minimap in the XI look: a square map in a navy window with a steel
-- edge, Blizzard's round border art faded, and the zone name on a navy
-- strip above it.
--
-- Only looks: the map's mask texture and the alpha of Blizzard's art. The
-- minimap cluster is an Edit Mode frame and is never moved or re-parented;
-- place it in Edit Mode and the window follows. A /reload is needed to go
-- back to the round map.
local _, ns = ...

local M = ns.AddModule("MapSkin")

-- Round decoration on the minimap, by name or by key on the cluster/map.
local ART_NAMES = { "MinimapBorder", "MinimapBorderTop", "MinimapCompassTexture", "MinimapBackdrop",
  "MinimapNorthTag" }
local ART_KEYS = { "BorderTop", "Border", "Background" }

local faded = {}
local function KeepFaded(region)
  if faded[region] and region:GetAlpha() > 0 then region:SetAlpha(0) end
end

local function Fade(region)
  if type(region) ~= "table" or not region.SetAlpha then return end
  region:SetAlpha(0)
  if not faded[region] then
    faded[region] = true
    hooksecurefunc(region, "SetAlpha", KeepFaded)
  end
end

-- Addons that put buttons around the map (LibDBIcon) ask this to know where
-- the edge is.
local function SquareShape() return "SQUARE" end

function M:Init()
  if not ns.db.map.skin or type(Minimap) ~= "table" then return end
  local map = Minimap

  if ns.db.map.square and map.SetMaskTexture then
    pcall(map.SetMaskTexture, map, "Interface\\Buttons\\WHITE8X8")
    GetMinimapShape = SquareShape
  end
  for _, name in ipairs(ART_NAMES) do Fade(_G[name]) end
  local cluster = MinimapCluster
  for _, key in ipairs(ART_KEYS) do
    if cluster then Fade(cluster[key]) end
    if key ~= "Background" then Fade(map[key]) end
  end

  -- The window: a plain frame behind the map.
  local back = CreateFrame("Frame", nil, map)
  back:SetFrameLevel(math.max(0, map:GetFrameLevel() - 1))
  back:SetPoint("TOPLEFT", map, "TOPLEFT", -4, 4)
  back:SetPoint("BOTTOMRIGHT", map, "BOTTOMRIGHT", 4, -4)
  ns.Style.Panel(back, 0.95)
  self.back = back

  -- Zone name strip, behind Blizzard's own zone text button.
  -- It covers the art it replaces (the cluster's top border), else the button.
  local zone = cluster and (cluster.ZoneTextButton or MinimapZoneTextButton)
  local spot = cluster and cluster.BorderTop
  if type(spot) ~= "table" or not spot.GetCenter then spot = zone end
  if type(spot) == "table" and spot.GetCenter then
    local strip = CreateFrame("Frame", nil, cluster)
    local level = (zone and zone.GetFrameLevel and zone:GetFrameLevel()) or cluster:GetFrameLevel()
    strip:SetFrameLevel(math.max(0, level - 1))
    strip:SetAllPoints(spot)
    ns.Style.Panel(strip, 0.9)
    self.strip = strip
  end
end

-- For /fxi check: what the built-in damage meter is called on this client,
-- so its window can be skinned next.
function M.DamageMeterNames()
  local out = {}
  for _, name in ipairs({ "DamageMeter", "DamageMeterFrame", "DamageMeterSessionWindow1", "DamageMeterWindow1" }) do
    if type(_G[name]) == "table" then out[#out + 1] = name end
  end
  return #out > 0 and table.concat(out, " ") or "none found"
end
