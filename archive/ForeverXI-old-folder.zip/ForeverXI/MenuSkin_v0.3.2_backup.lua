-- Blizzard's micro menu and bag bar, sat in an XI navy window so they match
-- the rest. Only a panel is drawn BEHIND them: the Blizzard buttons are not
-- re-parented, moved or clicked for, because on Forever touching those from
-- addon code taints the game's windows. Place and size the two bars in
-- Edit Mode (Micro Menu and Bag Bar); the window follows them.
local _, ns = ...

local M = ns.AddModule("MenuSkin")

local function Behind(target)
  if type(target) ~= "table" or not target.GetCenter then return nil end
  local p = CreateFrame("Frame", nil, UIParent)
  p:SetFrameStrata("BACKGROUND")
  p:SetPoint("TOPLEFT", target, "TOPLEFT", -5, 5)
  p:SetPoint("BOTTOMRIGHT", target, "BOTTOMRIGHT", 5, -5)
  ns.Style.Panel(p, 0.88)
  -- Follow the bar's own visibility (vehicles, pet battles, Edit Mode).
  if target.HookScript then
    target:HookScript("OnShow", function() p:Show() end)
    target:HookScript("OnHide", function() p:Hide() end)
  end
  p:SetShown(target:IsShown())
  return p
end

-- The bag bar, put away. It is an Edit Mode frame, so it is faded and its
-- buttons taken off the mouse, never hidden or moved (that taints Edit Mode
-- on Forever). The bag keys (B, Shift+B) still open bags.
local BAG_BUTTONS = { "MainMenuBarBackpackButton", "CharacterBag0Slot", "CharacterBag1Slot",
  "CharacterBag2Slot", "CharacterBag3Slot", "CharacterReagentBag0Slot", "BagBarExpandToggle" }
local fadedBags = false

local function KeepFaded(frame)
  if fadedBags and frame:GetAlpha() > 0 then frame:SetAlpha(0) end
end

local function HideBagBar()
  local bar = BagsBar
  if type(bar) ~= "table" or not bar.SetAlpha then return end
  fadedBags = true
  bar:SetAlpha(0)
  hooksecurefunc(bar, "SetAlpha", KeepFaded)
  for _, name in ipairs(BAG_BUTTONS) do
    local b = _G[name]
    if type(b) == "table" and b.EnableMouse then pcall(b.EnableMouse, b, false) end
  end
end

function M:Init()
  if ns.db.hideBagBar then
    ns.AfterCombat("hideBagBar", HideBagBar)
  end
  if not ns.db.menuSkin then return end
  self.micro = Behind(MicroMenuContainer or MicroMenu or MicroButtonAndBagsBar)
  if not ns.db.hideBagBar then self.bags = Behind(BagsBar) end
end
