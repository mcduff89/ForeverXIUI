-- XI-style action bars: an XI navy window behind Blizzard's bars 1-3, and a
-- "which bar is live" highlight. Hold Alt and the Alt bar lights up, hold
-- Ctrl and the Ctrl bar does; the others dim. Let go and bar 1 is live.
--
-- The bars themselves are Blizzard's and are never moved, re-parented or
-- clicked for (that taints Edit Mode on Forever). We only draw our own
-- frames behind and around them and change their alpha, which is allowed
-- in combat. Place and size the bars in Edit Mode.
local _, ns = ...

local M = ns.AddModule("ActionBars")

-- Which Blizzard bar is which. Names differ between client versions.
local BARS = {
  base = { "MainActionBar", "MainMenuBar" },
  alt  = { "MultiBarBottomLeft" },
  ctrl = { "MultiBarBottomRight" },
}

local function Find(names)
  for _, n in ipairs(names) do
    local f = _G[n]
    if type(f) == "table" and f.GetCenter then return f, n end
  end
end

local slots = {}

local function Build(key, bar)
  local back = CreateFrame("Frame", nil, UIParent)
  back:SetFrameStrata("BACKGROUND")
  back:SetPoint("TOPLEFT", bar, "TOPLEFT", -5, 5)
  back:SetPoint("BOTTOMRIGHT", bar, "BOTTOMRIGHT", 5, -5)
  ns.Style.Panel(back, 0.85)

  -- The live-bar glow: a brighter steel-blue edge just outside the window.
  local glow = CreateFrame("Frame", nil, UIParent)
  glow:SetFrameStrata("BACKGROUND")
  glow:SetPoint("TOPLEFT", back, "TOPLEFT", -2, 2)
  glow:SetPoint("BOTTOMRIGHT", back, "BOTTOMRIGHT", 2, -2)
  local lr, lg, lb = ns.Style.Color("edgeLight")
  glow.edges = {}
  for _, spec in ipairs({
    { "TOPLEFT", "TOPRIGHT", nil, 2 }, { "BOTTOMLEFT", "BOTTOMRIGHT", nil, 2 },
    { "TOPLEFT", "BOTTOMLEFT", 2, nil }, { "TOPRIGHT", "BOTTOMRIGHT", 2, nil },
  }) do
    local t = glow:CreateTexture(nil, "OVERLAY")
    t:SetColorTexture(lr, lg, lb, 0.9)
    t:SetPoint(spec[1])
    t:SetPoint(spec[2])
    if spec[3] then t:SetWidth(spec[3]) end
    if spec[4] then t:SetHeight(spec[4]) end
    table.insert(glow.edges, t)
  end
  local label = ns.Style.Text(glow, 10)
  label:SetPoint("BOTTOMLEFT", back, "TOPLEFT", 3, 1)
  label:SetTextColor(lr, lg, lb)
  label:SetText(key == "alt" and "Alt" or key == "ctrl" and "Ctrl" or "")
  glow:Hide()

  -- Follow the bar's own visibility (vehicles, pet battles, bar turned off).
  local function Sync()
    local shown = bar:IsShown()
    back:SetShown(shown)
    if not shown then glow:Hide() end
  end
  bar:HookScript("OnShow", Sync)
  bar:HookScript("OnHide", Sync)
  Sync()

  slots[key] = { bar = bar, back = back, glow = glow }
end

local current
local function Highlight()
  local live = "base"
  if IsControlKeyDown() then
    live = "ctrl"
  elseif IsAltKeyDown() then
    live = "alt"
  end
  if live == current then return end
  current = live
  local dim = tonumber(ns.db.bars.dimAlpha) or 0.55
  local any = live ~= "base"
  for key, s in pairs(slots) do
    local on = key == live
    s.glow:SetShown(on and (any or ns.db.bars.glowBase))
    if ns.db.bars.dim then
      s.bar:SetAlpha((on or not any) and 1 or dim)
    end
  end
end

function M:Init()
  if not ns.db.bars.enabled then return end
  for key, names in pairs(BARS) do
    local bar = Find(names)
    if bar then Build(key, bar) end
  end
  if not next(slots) then
    ns.Print("couldn't find Blizzard's action bars on this client; the bar skin is off.")
    return
  end
  ns.On("MODIFIER_STATE_CHANGED", Highlight)
  -- Letting go of Alt/Ctrl while a menu has focus can skip the event.
  ns.On("PLAYER_REGEN_ENABLED", Highlight)
  current = nil
  Highlight()
end

function M:Relayout()
  current = nil
  if next(slots) then Highlight() end
end

-- For /fxi check.
function M:Names()
  local out = {}
  for key, names in pairs(BARS) do
    local _, n = Find(names)
    table.insert(out, key .. "=" .. tostring(n))
  end
  table.sort(out)
  return table.concat(out, " ")
end
