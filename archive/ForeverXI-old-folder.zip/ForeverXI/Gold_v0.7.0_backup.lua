-- Gold (XIUI's gil tracker), shown as a line under the EXP bar: your gold,
-- how much you've made (or spent) this session and per hour. The EXP bar's
-- tooltip lists every character's gold on this account and the total.
-- Ctrl-click the EXP bar to reset both sessions.
--
-- The per-character list is kept in ForeverXIDB.gold, by realm and name.
local _, ns = ...

local M = ns.AddModule("Gold")

local G, S = 10000, 100
local GOLD = "|TInterface\\MoneyFrame\\UI-GoldIcon:0:0:1:0|t"
local SILVER = "|TInterface\\MoneyFrame\\UI-SilverIcon:0:0:1:0|t"
local COPPER = "|TInterface\\MoneyFrame\\UI-CopperIcon:0:0:1:0|t"

local session = { start = nil, money = 0, at = 0 }

local function Coins(c, short)
  c = math.floor(math.abs(c or 0))
  local g, s, cp = math.floor(c / G), math.floor((c % G) / S), c % S
  local out = {}
  if g > 0 then out[#out + 1] = (BreakUpLargeNumbers and BreakUpLargeNumbers(g) or g) .. GOLD end
  if s > 0 or (g > 0 and not short) then out[#out + 1] = s .. SILVER end
  if not short or g == 0 then out[#out + 1] = cp .. COPPER end
  return table.concat(out, " ")
end

local function Signed(c)
  if c == 0 then return "|cffaaaaaa0|r" end
  return (c > 0 and "|cff7fd27f+" or "|cffec6c6c-") .. Coins(c, true) .. "|r"
end

local function Me()
  local realm = GetRealmName and GetRealmName() or "?"
  local name = UnitName("player") or "?"
  return realm, name
end

local function Save(money)
  local realm, name = Me()
  ns.db.gold = ns.db.gold or {}
  ns.db.gold[realm] = ns.db.gold[realm] or {}
  local _, class = UnitClass("player")
  ns.db.gold[realm][name] = { money = money, class = class, seen = time() }
end

-- The gold line on the EXP bar: "31g 23s 45c  +4g 52s  +2g 21s/h".
function M.Line()
  local money = GetMoney() or 0
  local change = money - session.money
  local out = Coins(money, true)
  if change ~= 0 then
    out = out .. "  " .. Signed(change)
    local hours = (GetTime() - session.at) / 3600
    if ns.db.goldTracker.showRate and hours > 0.05 then
      out = out .. "  " .. Signed(change / hours) .. "|cffaaaaaa/h|r"
    end
  end
  return out
end

function M.PreviewLine()
  return Coins(312345, true) .. "  " .. Signed(4520) .. "  " .. Signed(2210) .. "|cffaaaaaa/h|r"
end

function M.Reset()
  session.money, session.at = GetMoney() or 0, GetTime()
end

function M.Enabled() return ns.db.modules.gold and true or false end

-- Added to the bottom of the EXP bar's tooltip.
function M.AddTooltip()
  GameTooltip:AddLine(" ")
  GameTooltip:AddLine("Gold", 0.72, 0.79, 1)
  local money = GetMoney() or 0
  local change = money - session.money
  GameTooltip:AddDoubleLine("This session", Signed(change), 1, 1, 1)
  local hours = (GetTime() - session.at) / 3600
  if hours > 0.05 then GameTooltip:AddDoubleLine("Per hour", Signed(change / hours), 1, 1, 1) end
  local total = 0
  for realm, chars in pairs(ns.db.gold or {}) do
    GameTooltip:AddLine(realm, 0.55, 0.62, 0.8)
    local list = {}
    for name, d in pairs(chars) do list[#list + 1] = { name, d } end
    table.sort(list, function(x, y) return (x[2].money or 0) > (y[2].money or 0) end)
    for _, e in ipairs(list) do
      local c = RAID_CLASS_COLORS and e[2].class and RAID_CLASS_COLORS[e[2].class]
      GameTooltip:AddDoubleLine("  " .. e[1], Coins(e[2].money, true), c and c.r or 1, c and c.g or 1, c and c.b or 1, 1, 1, 1)
      total = total + (e[2].money or 0)
    end
  end
  GameTooltip:AddDoubleLine("All characters", Coins(total, true), 1, 0.82, 0, 1, 1, 1)
end

function M:Init()
  ns.db.goldTracker = ns.db.goldTracker or {}
  session.money, session.at = GetMoney() or 0, GetTime()
  Save(session.money)
  ns.On("PLAYER_MONEY", function() Save(GetMoney() or 0) end)
end
