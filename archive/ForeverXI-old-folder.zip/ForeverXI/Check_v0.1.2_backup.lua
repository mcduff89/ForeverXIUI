-- /fxi check: what this Forever client lets addons read right now. Run it
-- out of combat, then again in combat with a mob targeted, and send the
-- output. It only reads; nothing is changed.
local _, ns = ...

local function Say(label, value)
  print(("  %s: |cffffffff%s|r"):format(label, value))
end

local function Describe(fn, ...)
  local ok, v = pcall(fn, ...)
  if not ok then return "error" end
  if type(v) == "nil" then return "nil" end
  if issecretvalue and issecretvalue(v) then return type(v) .. " (secret)" end
  return tostring(v)
end

function ns.Check()
  ns.Print("check (%s):", InCombatLockdown() and "IN combat" or "out of combat")
  local _, build, _, iface = GetBuildInfo()
  Say("build / interface", tostring(build) .. " / " .. tostring(iface))
  Say("issecretvalue exists", tostring(issecretvalue ~= nil))
  Say("C_Secrets exists", tostring(C_Secrets ~= nil))
  if C_Secrets and C_Secrets.ShouldAurasBeSecret then
    Say("auras secret now", Describe(C_Secrets.ShouldAurasBeSecret))
  end
  Say("C_CurveUtil exists", tostring(C_CurveUtil ~= nil))
  Say("UnitHealthPercent exists", tostring(UnitHealthPercent ~= nil))
  Say("percent curve built", tostring(ns.Values.PercentCurve() ~= nil))
  Say("player health", Describe(UnitHealth, "player"))
  Say("player max health", Describe(UnitHealthMax, "player"))
  Say("player mana", Describe(UnitPower, "player"))
  if UnitExists("target") then
    Say("target name", Describe(UnitName, "target"))
    Say("target health", Describe(UnitHealth, "target"))
    Say("target max health", Describe(UnitHealthMax, "target"))
    Say("target casting", Describe(UnitCastingInfo, "target"))
  else
    Say("target", "none (target a mob and run again)")
  end
  Say("Settings API", tostring(Settings ~= nil and Settings.RegisterAddOnSetting ~= nil))
  Say("Edit Mode callbacks", tostring(EventRegistry ~= nil))
end
