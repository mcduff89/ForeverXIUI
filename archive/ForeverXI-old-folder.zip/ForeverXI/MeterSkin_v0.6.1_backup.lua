-- Damage meter skin: the game's built-in damage meter in an XI window.
-- Only looks: a navy panel with the steel edge behind each meter window,
-- and Blizzard's own background art faded. The meter is an Edit Mode frame,
-- so it is never moved, re-parented or hidden; place it in Edit Mode and
-- the window follows.
--
-- Blizzard hasn't documented the meter's frame names for addons, so this
-- looks in a few places (the global name, Edit Mode's registered system)
-- and skins every window it finds. /fxi check says what it found.
local _, ns = ...

local M = ns.AddModule("MeterSkin")

local NAMES = { "DamageMeter", "DamageMeterFrame" }
local DECOR = { "NineSlice", "Background", "Bg", "BackgroundTexture", "Backdrop", "Border" }

local faded, skinned, found = {}, {}, {}
local Kind

local function KeepFaded(region)
  if faded[region] and region:GetAlpha() > 0 then region:SetAlpha(0) end
end

local function Fade(region)
  if type(region) ~= "table" or not region.SetAlpha or region.fxiOurs then return end
  region:SetAlpha(0)
  if not faded[region] then
    faded[region] = true
    hooksecurefunc(region, "SetAlpha", KeepFaded)
  end
end

Kind = function(f)
  local ok, k = pcall(f.GetObjectType, f)
  return ok and k or nil
end

-- The window's header: a child frame along its top edge (the "Damage Done"
-- strip with the dropdown and buttons), or a key Blizzard may give it.
local HEADER_KEYS = { "Header", "HeaderBar", "TitleBar", "Title", "TitleContainer" }
local headers = {}

local function FindHeader(win)
  for _, key in ipairs(HEADER_KEYS) do
    local h = rawget(win, key)
    if type(h) == "table" and h.GetRegions and Kind(h) ~= "FontString" then return h end
  end
  local top, w = win:GetTop(), win:GetWidth() or 0
  if not top then return nil end
  for _, child in ipairs({ win:GetChildren() }) do
    if not child.fxiOurs and Kind(child) == "Frame" then
      local ct, ch, cw = child:GetTop(), child:GetHeight() or 0, child:GetWidth() or 0
      if ct and math.abs(ct - top) <= 4 and ch >= 14 and ch <= 34 and cw >= w * 0.5 then return child end
    end
  end
end

local function SkinHeader(win)
  if headers[win] then return end
  local h = FindHeader(win)
  if not h then return end
  headers[win] = h
  ns.Style.Header(h, { size = 12 })
  -- Blizzard sometimes lays its header art right on the window itself.
  for _, r in ipairs({ win:GetRegions() }) do
    if Kind(r) == "Texture" and not r.fxiOurs then
      local rt, wt = r:GetTop(), win:GetTop()
      if rt and wt and math.abs(rt - wt) <= 4 and (r:GetHeight() or 0) <= 34 then Fade(r) end
    end
  end
end

-- One meter window: fade its decoration, put our panel just under it.
local function Skin(win)
  if type(win) ~= "table" or not win.GetFrameLevel then return end
  if skinned[win] then SkinHeader(win) return end
  local w = win.GetWidth and win:GetWidth() or 0
  if w < 60 then return end          -- buttons and bits, not a window
  skinned[win] = true
  for _, key in ipairs(DECOR) do
    local r = rawget(win, key)
    if type(r) == "table" and (Kind(r) == "Texture" or key == "NineSlice") then Fade(r) end
  end
  local back = CreateFrame("Frame", nil, win)
  back.fxiOurs = true
  back:SetFrameLevel(math.max(0, win:GetFrameLevel() - 1))
  back:SetPoint("TOPLEFT", win, "TOPLEFT", -2, 2)
  back:SetPoint("BOTTOMRIGHT", win, "BOTTOMRIGHT", 2, -2)
  ns.Style.Panel(back, 0.9)
  found[#found + 1] = win:GetName() or "window"
  SkinHeader(win)
  win:HookScript("OnShow", function() C_Timer.After(0, function() SkinHeader(win) end) end)
end

local function Roots()
  local out = {}
  for _, n in ipairs(NAMES) do
    if type(_G[n]) == "table" then out[#out + 1] = _G[n] end
  end
  if EditModeManagerFrame and EditModeManagerFrame.GetRegisteredSystemFrame
    and Enum and Enum.EditModeSystem and Enum.EditModeSystem.DamageMeter then
    local ok, f = pcall(EditModeManagerFrame.GetRegisteredSystemFrame, EditModeManagerFrame,
      Enum.EditModeSystem.DamageMeter)
    if ok and type(f) == "table" then out[#out + 1] = f end
  end
  return out
end

function M.Apply()
  if not ns.db.meter.skin then return end
  for _, root in ipairs(Roots()) do
    -- The meter's windows are its children (one per session window);
    -- if it has none that look like windows, skin the meter itself.
    local before = #found
    if root.GetChildren then
      for _, child in ipairs({ root:GetChildren() }) do
        if not child.fxiOurs and Kind(child) == "Frame" and (child:GetHeight() or 0) > 40 then Skin(child) end
      end
    end
    if #found == before then Skin(root) end
    if not headers[root] and root.GetTop then SkinHeader(root) end
  end
end

function M:Init()
  if not ns.db.meter.skin then return end
  M.Apply()
  -- The meter loads on demand; skin it when it does, and when new windows open.
  ns.On("ADDON_LOADED", function(_, name)
    if type(name) == "string" and name:find("DamageMeter") then C_Timer.After(0.2, M.Apply) end
  end)
  ns.On("PLAYER_ENTERING_WORLD", function() C_Timer.After(2, M.Apply) end)
  ns.On("PLAYER_REGEN_DISABLED", M.Apply)
  for _, t in ipairs({ 1, 4 }) do C_Timer.After(t, M.Apply) end
end

-- /fxi meter: what the meter is made of, to fit the skin to it.
local function Dump(f, depth, label)
  if depth > 2 then return end
  local name = (f.GetName and f:GetName()) or label or "?"
  local w, h = f.GetWidth and f:GetWidth() or 0, f.GetHeight and f:GetHeight() or 0
  print(("%s%s [%s] %dx%d%s"):format(string.rep("  ", depth), name, Kind(f) or "?", w, h,
    headers[f] and " (header found)" or ""))
  local keys = {}
  for k, v in pairs(f) do
    if type(k) == "string" and type(v) == "table" and v.GetObjectType and k ~= "fxiHeader" then keys[#keys + 1] = k end
  end
  table.sort(keys)
  if #keys > 0 then print(string.rep("  ", depth + 1) .. "keys: " .. table.concat(keys, ", ", 1, math.min(#keys, 14))) end
  if f.GetChildren then
    for _, c in ipairs({ f:GetChildren() }) do
      if not c.fxiOurs then Dump(c, depth + 1) end
    end
  end
end

function M.Dump()
  local roots = Roots()
  if #roots == 0 then ns.Print("no damage meter found. Open it and try again.") return end
  ns.Print("damage meter layout:")
  for _, r in ipairs(roots) do Dump(r, 0) end
end

function M.Describe()
  local roots = {}
  for _, r in ipairs(Roots()) do roots[#roots + 1] = (r.GetName and r:GetName()) or "unnamed" end
  if #roots == 0 then return "none found (open the meter once, then check again)" end
  return ("%s; skinned %d: %s"):format(table.concat(roots, " "), #found,
    #found > 0 and table.concat(found, " ") or "-")
end
