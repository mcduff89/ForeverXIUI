-- Gold tracker (XIUI's gil tracker): a small XI window with your gold, and
-- how much you've made (or spent) this session and per hour. Hover for every
-- character's gold on this account and the total. Shift-click to post your
-- gold to chat; ctrl-click to reset the session.
--
-- The per-character list is kept in ForeverXIDB.gold, by realm and name.
local _, ns = ...

local M = ns.AddModule("Gold")

local G, S = 10000, 100
local GOLD = "|TInterface\\MoneyFrame\\UI-GoldIcon:0:0:1:0|t"
local SILVER = "|TInterface\\MoneyFrame\\UI-SilverIcon:0:0:1:0|t"
local COPPER = "|TInterface\\MoneyFrame\\UI-CopperIcon:0:0:1:0|t"

local session = { start = nil, money = 0, at = 0 }

local function Coins(c, short)
  c = math.floor(math.abs(c or 0))
  local g, s, cp = math.floor(c / G), math.floor((c % G) / S), c % S
  local out = {}
  if g > 0 then out[#out + 1] = (BreakUpLargeNumbers and BreakUpLargeNumbers(g) or g) .. GOLD end
  if s > 0 or (g > 0 and not short) then out[#out + 1] = s .. SILVER end
  if not short or g == 0 then out[#out + 1] = cp .. COPPER end
  return table.concat(out, " ")
end

local function Signed(c)
  if c == 0 then return "|cffaaaaaa0|r" end
  return (c > 0 and "|cff7fd27f+" or "|cffec6c6c-") .. Coins(c, true) .. "|r"
end

local function Me()
  local realm = GetRealmName and GetRealmName() or "?"
  local name = UnitName("player") or "?"
  return realm, name
end

local function Save(money)
  local realm, name = Me()
  ns.db.gold = ns.db.gold or {}
  ns.db.gold[realm] = ns.db.gold[realm] or {}
  local _, class = UnitClass("player")
  ns.db.gold[realm][name] = { money = money, class = class, seen = time() }
end

local function Draw(f)
  if f.previewing then return end
  local money = GetMoney() or 0
  local change = money - session.money
  f.money:SetText(Coins(money, true))
  local hours = (GetTime() - session.at) / 3600
  if ns.db.goldTracker.showRate and hours > 0.05 and change ~= 0 then
    f.rate:SetText(Signed(change) .. "  " .. Signed(change / hours) .. "|cffaaaaaa/h|r")
  else
    f.rate:SetText(change ~= 0 and Signed(change) or "")
  end
  f:SetWidth(math.max(90, (f.money:GetStringWidth() or 60) + (f.rate:GetStringWidth() or 0) + 26))
end

local function Tooltip(f)
  GameTooltip:SetOwner(f, "ANCHOR_TOP")
  GameTooltip:AddLine("Gold", 0.72, 0.79, 1)
  local money = GetMoney() or 0
  local change = money - session.money
  GameTooltip:AddDoubleLine("This session", Signed(change), 1, 1, 1)
  local hours = (GetTime() - session.at) / 3600
  if hours > 0.05 then GameTooltip:AddDoubleLine("Per hour", Signed(change / hours), 1, 1, 1) end
  local total = 0
  for realm, chars in pairs(ns.db.gold or {}) do
    GameTooltip:AddLine(" ")
    GameTooltip:AddLine(realm, 0.72, 0.79, 1)
    local list = {}
    for name, d in pairs(chars) do list[#list + 1] = { name, d } end
    table.sort(list, function(a, b) return (a[2].money or 0) > (b[2].money or 0) end)
    for _, e in ipairs(list) do
      local c = RAID_CLASS_COLORS and e[2].class and RAID_CLASS_COLORS[e[2].class]
      GameTooltip:AddDoubleLine(e[1], Coins(e[2].money, true), c and c.r or 1, c and c.g or 1, c and c.b or 1, 1, 1, 1)
      total = total + (e[2].money or 0)
    end
  end
  GameTooltip:AddLine(" ")
  GameTooltip:AddDoubleLine("All characters", Coins(total, true), 1, 0.82, 0, 1, 1, 1)
  GameTooltip:AddLine("Shift-click: post to chat. Ctrl-click: reset the session.", 0.55, 0.55, 0.55, true)
  GameTooltip:Show()
end

function M:Init()
  ns.db.goldTracker = ns.db.goldTracker or {}
  session.money, session.at = GetMoney() or 0, GetTime()
  Save(session.money)
  if not ns.db.modules.gold then
    ns.On("PLAYER_MONEY", function() Save(GetMoney() or 0) end)
    return
  end
  local f = CreateFrame("Frame", "ForeverXIGold", UIParent)
  f:SetSize(120, 20)
  ns.Style.Panel(f, 0.9)
  f.money = ns.Style.Text(f, 11)
  f.money:SetPoint("LEFT", f, "LEFT", 7, 0)
  f.rate = ns.Style.Text(f, 10)
  f.rate:SetPoint("RIGHT", f, "RIGHT", -7, 0)
  f:EnableMouse(true)
  f:SetScript("OnEnter", Tooltip)
  f:SetScript("OnLeave", function() GameTooltip:Hide() end)
  f:SetScript("OnMouseUp", function(self, button)
    if button ~= "LeftButton" then return end
    if IsControlKeyDown() then
      session.money, session.at = GetMoney() or 0, GetTime()
      ns.Print("gold session reset.")
      Draw(self)
    elseif IsShiftKeyDown() and ChatEdit_InsertLink then
      ChatEdit_InsertLink(("Gold: %s"):format(GetCoinText and GetCoinText(GetMoney() or 0, " ") or tostring(GetMoney())))
    end
  end)
  f:RegisterEvent("PLAYER_MONEY")
  f:RegisterEvent("PLAYER_ENTERING_WORLD")
  f:SetScript("OnEvent", function(self)
    Save(GetMoney() or 0)
    Draw(self)
  end)
  -- Per-hour drifts as time passes; once a minute is enough.
  local acc = 0
  f:SetScript("OnUpdate", function(self, dt)
    acc = acc + dt
    if acc < 60 then return end
    acc = 0
    Draw(self)
  end)
  Draw(f)

  self.frame = f
  ns.AddRoot(f, "gold")
  ns.Movers.Register("gold", "Gold", f, { "BOTTOM", "BOTTOM", 305, 92 })
end

function M:Preview(on)
  local f = self.frame
  if not f then return end
  f.previewing = on and true or nil
  if on then
    f.money:SetText(Coins(312345, true))
    f.rate:SetText(Signed(4520) .. "  " .. Signed(2210) .. "|cffaaaaaa/h|r")
    f:SetWidth(math.max(90, (f.money:GetStringWidth() or 60) + (f.rate:GetStringWidth() or 0) + 26))
  else
    Draw(f)
  end
end
