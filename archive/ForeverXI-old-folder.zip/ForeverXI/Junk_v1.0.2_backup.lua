-- Junk by price: a junk rule for Baganator that uses your Auctionator scan.
-- An item counts as junk when selling it on the auction house (after the
-- 5% cut) wouldn't beat the vendor by more than the margin you set. Grey
-- items are always junk. Baganator then shows its junk coin on them and
-- puts them in its Junk section. At a vendor a window lists them with a tick
-- box each; untick what you want to keep (remembered), then click Sell.
--
-- Never junk: items that can't be sold to a vendor, items with no
-- Auctionator price (bound gear, things you haven't scanned), epics and up,
-- and (by default) weapons and armour that aren't grey.
local _, ns = ...

local M = ns.AddModule("Junk")

local CALLER = "ForeverXI"
local AH_CUT = 0.95

local function o() return ns.db.junk end

local function SellPrice(itemLink, itemID)
  local get = (C_Item and C_Item.GetItemInfo) or GetItemInfo
  if not get then return end
  local ok, _, _, quality, _, _, _, _, _, _, _, sell, classID = pcall(get, itemLink or itemID)
  if not ok then return end
  return sell, quality, classID
end

local function AuctionPrice(itemLink, itemID)
  local api = Auctionator and Auctionator.API and Auctionator.API.v1
  if not api then return end
  if itemLink and api.GetAuctionPriceByItemLink then
    local ok, p = pcall(api.GetAuctionPriceByItemLink, CALLER, itemLink)
    if ok and type(p) == "number" then return p end
  end
  if itemID and api.GetAuctionPriceByItemID then
    local ok, p = pcall(api.GetAuctionPriceByItemID, CALLER, itemID)
    if ok and type(p) == "number" then return p end
  end
end

local GEAR = { [2] = true, [4] = true }   -- weapon, armour item classes

-- true: junk. Exposed for /fxi check and testing.
-- ignoreKeep: the vendor window lists kept items too (unticked).
function M.IsJunk(itemLink, itemID, ignoreKeep)
  if o().enabled == false then return false end
  if not ignoreKeep and itemID and o().keep and o().keep[itemID] then return false end
  local sell, quality, classID = SellPrice(itemLink, itemID)
  if type(sell) ~= "number" or sell <= 0 then return false end
  if quality == 0 then return true end
  if type(quality) == "number" and quality >= 4 then return false end
  if o().keepGear ~= false and GEAR[classID] then return false end
  local ah = AuctionPrice(itemLink, itemID)
  if not ah then return false end
  local margin = (tonumber(o().margin) or 0) * 100   -- silver to copper
  return ah * AH_CUT <= sell + margin
end

function M.Refresh()
  local api = Baganator and Baganator.API
  if api and api.RequestItemButtonsRefresh then pcall(api.RequestItemButtonsRefresh) end
end

---------------------------------------------------------------------------
-- The vendor window: everything the rule marks, with a tick box each.
-- Unticking an item keeps it (remembered, and Baganator stops calling it
-- junk); ticking it again lets it be junk. "Sell" sells the ticked ones.
---------------------------------------------------------------------------
local ROWS, ROW_H, WIN_W = 12, 20, 300
local win, list, offset = nil, {}, 0
local selling, earned, count = false, 0, 0

local function Coins(c)
  c = math.floor(c or 0)
  if GetCoinTextureString then return GetCoinTextureString(c) end
  return ("%dg %ds %dc"):format(math.floor(c / 10000), math.floor(c / 100) % 100, c % 100)
end

local function Container()
  local C = C_Container
  return (C and C.GetContainerNumSlots) or GetContainerNumSlots, C and C.GetContainerItemInfo,
    (C and C.UseContainerItem) or UseContainerItem
end

-- One entry per item kind: { itemID, link, icon, quality, count, value, slots = {{bag, slot}} }
local function Collect()
  local numSlots, getInfo = Container()
  local byID, out = {}, {}
  if not (numSlots and getInfo) then return out end
  for bag = 0, (NUM_BAG_SLOTS or 4) do
    local okN, n = pcall(numSlots, bag)
    for slot = 1, (okN and type(n) == "number" and n or 0) do
      local okI, info = pcall(getInfo, bag, slot)
      if okI and type(info) == "table" and info.itemID and not info.hasNoValue then
        local okJ, junk = pcall(M.IsJunk, info.hyperlink, info.itemID, true)
        if okJ and junk then
          local e = byID[info.itemID]
          if not e then
            local sell, quality = SellPrice(info.hyperlink, info.itemID)
            e = { itemID = info.itemID, link = info.hyperlink, icon = info.iconFileID,
              quality = info.quality or quality, unit = sell or 0, count = 0, slots = {} }
            byID[info.itemID] = e
            out[#out + 1] = e
          end
          e.count = e.count + (info.stackCount or 1)
          e.slots[#e.slots + 1] = { bag, slot }
        end
      end
    end
  end
  table.sort(out, function(a, b) return a.unit * a.count > b.unit * b.count end)
  return out
end

local function Kept(e) return o().keep and o().keep[e.itemID] end

local function Draw()
  if not win then return end
  local total, n = 0, 0
  for _, e in ipairs(list) do
    if not Kept(e) then total, n = total + e.unit * e.count, n + 1 end
  end
  offset = math.max(0, math.min(offset, #list - ROWS))
  for i = 1, ROWS do
    local row, e = win.rows[i], list[i + offset]
    row.entry = e
    if e then
      row.check:SetChecked(not Kept(e))
      row.icon:SetTexture(e.icon)
      local c = ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[e.quality or 1]
      local name = (C_Item and C_Item.GetItemNameByID and C_Item.GetItemNameByID(e.itemID)) or e.link or "?"
      row.name:SetText(e.count > 1 and (name .. " x" .. e.count) or name)
      if c then row.name:SetTextColor(c.r, c.g, c.b) else row.name:SetTextColor(1, 1, 1) end
      row.value:SetText(Coins(e.unit * e.count))
      row:SetAlpha(Kept(e) and 0.5 or 1)
      row:Show()
    else
      row:Hide()
    end
  end
  win.total:SetText(n > 0 and ("%d to sell: %s"):format(n, Coins(total)) or "Nothing ticked")
  win.sell:SetEnabled(n > 0 and not selling)
  local shown = math.min(#list, ROWS)
  win:SetHeight(34 + math.max(1, shown) * ROW_H + 34)
end

local function SellNext()
  if not selling then return end
  local _, getInfo, use = Container()
  local sold = 0
  for _, e in ipairs(list) do
    if not Kept(e) then
      for k = #e.slots, 1, -1 do
        local bag, slot = e.slots[k][1], e.slots[k][2]
        local okI, info = pcall(getInfo, bag, slot)
        if okI and type(info) == "table" and info.itemID == e.itemID and not info.isLocked then
          if pcall(use, bag, slot) then
            earned = earned + e.unit * (info.stackCount or 1)
            count = count + 1
            sold = sold + 1
          end
        end
        table.remove(e.slots, k)
        if sold >= 8 then
          C_Timer.After(0.3, SellNext)
          return
        end
      end
    end
  end
  selling = false
  if count > 0 then
    ns.Print("sold %d junk item%s for %s.", count, count == 1 and "" or "s", Coins(earned))
  end
  C_Timer.After(0.5, function() if win and win:IsShown() then M.Open() end end)
end

local function Build()
  local f = CreateFrame("Frame", "ForeverXIJunkWindow", UIParent)
  f:SetSize(WIN_W, 200)
  f:SetFrameStrata("HIGH")
  ns.Style.Panel(f, 0.95)
  f:EnableMouse(true)
  f:EnableMouseWheel(true)
  f:SetScript("OnMouseWheel", function(_, d) offset = offset - d; Draw() end)

  local title = ns.Style.Text(f, 13)
  title:SetPoint("TOPLEFT", 10, -9)
  title:SetText("Sell junk")
  title:SetTextColor(ns.Style.Color("title"))
  local hint = ns.Style.Text(f, 10)
  hint:SetPoint("TOPRIGHT", -10, -11)
  hint:SetText("untick to keep")
  hint:SetTextColor(0.6, 0.65, 0.75)

  f.rows = {}
  for i = 1, ROWS do
    local row = CreateFrame("Button", nil, f)
    row:SetSize(WIN_W - 16, ROW_H)
    row:SetPoint("TOPLEFT", 8, -30 - (i - 1) * ROW_H)
    local check = CreateFrame("CheckButton", nil, row, "UICheckButtonTemplate")
    check:SetSize(20, 20)
    check:SetPoint("LEFT", 0, 0)
    check:SetScript("OnClick", function(self)
      local e = row.entry
      if not e then return end
      o().keep = o().keep or {}
      o().keep[e.itemID] = (not self:GetChecked()) or nil
      M.Refresh()
      Draw()
    end)
    row.check = check
    row.icon = row:CreateTexture(nil, "ARTWORK")
    row.icon:SetSize(16, 16)
    row.icon:SetPoint("LEFT", check, "RIGHT", 2, 0)
    row.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    row.value = ns.Style.Text(row, 11)
    row.value:SetPoint("RIGHT", -2, 0)
    row.value:SetJustifyH("RIGHT")
    row.name = ns.Style.Text(row, 11)
    row.name:SetPoint("LEFT", row.icon, "RIGHT", 5, 0)
    row.name:SetPoint("RIGHT", row.value, "LEFT", -6, 0)
    row.name:SetJustifyH("LEFT")
    row.name:SetWordWrap(false)
    row:SetScript("OnEnter", function(self)
      if self.entry and self.entry.link then
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetHyperlink(self.entry.link)
        GameTooltip:Show()
      end
    end)
    row:SetScript("OnLeave", function() GameTooltip:Hide() end)
    row:SetScript("OnClick", function(self) self.check:Click() end)
    f.rows[i] = row
  end

  f.total = ns.Style.Text(f, 11)
  f.total:SetPoint("BOTTOMLEFT", 10, 12)

  local function Btn(label, w)
    local b = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
    b:SetSize(w, 20)
    b:SetText(label)
    return b
  end
  f.close = Btn("Close", 56)
  f.close:SetPoint("BOTTOMRIGHT", -8, 8)
  f.close:SetScript("OnClick", function() f:Hide() end)
  f.sell = Btn("Sell", 56)
  f.sell:SetPoint("RIGHT", f.close, "LEFT", -4, 0)
  f.sell:SetScript("OnClick", function()
    if selling then return end
    selling, earned, count = true, 0, 0
    Draw()
    SellNext()
  end)

  f:RegisterEvent("BAG_UPDATE_DELAYED")
  f:SetScript("OnEvent", function()
    if f:IsShown() and not selling then list = Collect(); Draw() end
  end)
  f:Hide()
  return f
end

function M.Open()
  if o().enabled == false or o().autoSell == false then return end
  list = Collect()
  if #list == 0 then
    if win then win:Hide() end
    return
  end
  win = win or Build()
  M.win = win
  win:ClearAllPoints()
  if MerchantFrame and MerchantFrame:IsShown() then
    win:SetPoint("TOPLEFT", MerchantFrame, "TOPRIGHT", 6, 0)
  else
    win:SetPoint("CENTER", UIParent, "CENTER", 250, 0)
  end
  offset = 0
  win:Show()
  Draw()
end

local function Closed()
  selling = false
  if win then win:Hide() end
end

function M:Init()
  ns.On("MERCHANT_SHOW", function() C_Timer.After(0.1, M.Open) end)
  ns.On("MERCHANT_CLOSED", Closed)
  local api = Baganator and Baganator.API
  if not (api and api.RegisterJunkPlugin) then return end
  if not (Auctionator and Auctionator.API and Auctionator.API.v1) then return end
  local ok = pcall(api.RegisterJunkPlugin, "ForeverXI: Auctionator price", "foreverxi_price",
    function(_, _, itemID, itemLink)
      local okJ, junk = pcall(M.IsJunk, itemLink, itemID)
      return okJ and junk or false
    end)
  self.active = ok
end

function M:Relayout()
  if self.active then M.Refresh() end
end

function M.Describe()
  if not M.active then return "off (needs Baganator and Auctionator)" end
  local live = Baganator.API.IsJunkPluginActive and Baganator.API.IsJunkPluginActive("foreverxi_price")
  return ("on, margin %ds, %s"):format(tonumber(o().margin) or 0,
    live and "chosen in Baganator" or "not chosen in Baganator yet (Customise > Junk)")
end
