-- Options in Blizzard's Settings panel (Esc > Options > AddOns > ForeverXI)
-- and the /fxi slash command.
local _, ns = ...

local M = ns.AddModule("Options")

local category

local function Changed(needsReload)
  return function()
    if needsReload then
      ns.Print("change saved. Type /reload to apply it.")
    else
      ns.ApplyScale()
      ns.ForEachModule("Relayout")
    end
  end
end

-- Each option: table, key, label, tooltip, default, needsReload.
local function Checkbox(cat, tbl, key, label, tooltip, needsReload)
  local variable = "ForeverXI_" .. label:gsub("%W", "")
  local setting = Settings.RegisterAddOnSetting(cat, variable, key, tbl, Settings.VarType.Boolean, label,
    tbl[key] and true or false)
  Settings.CreateCheckbox(cat, setting, tooltip)
  setting:SetValueChangedCallback(Changed(needsReload))
end

local function Build()
  local db = ns.db
  local cat = Settings.RegisterVerticalLayoutCategory("ForeverXI")
  -- Sections: each is its own page under ForeverXI in the AddOns list
  -- (click the arrow by ForeverXI to open them).
  local main = cat
  local function Sub(name)
    if Settings.RegisterVerticalLayoutSubcategory then
      local ok, sub = pcall(Settings.RegisterVerticalLayoutSubcategory, main, name)
      if ok and sub then return sub end
    end
    return main
  end
  local m = db.modules

  local scale = Settings.RegisterAddOnSetting(cat, "ForeverXI_Scale", "scale", db, Settings.VarType.Number,
    "Scale", 1)
  local opts = Settings.CreateSliderOptions(0.6, 1.6, 0.05)
  if MinimalSliderWithSteppersMixin and MinimalSliderWithSteppersMixin.Label then
    opts:SetLabelFormatter(MinimalSliderWithSteppersMixin.Label.Right, function(v) return ("%.2f"):format(v) end)
  end
  Settings.CreateSlider(cat, scale, opts, "Size of every ForeverXI frame.")
  scale:SetValueChangedCallback(Changed(false))

  Checkbox(cat, db, "compact", "Compact mode", "Narrower bars.", false)
  Checkbox(cat, db.look, "classicColors", "WoW health and power colours", "Red health, Blizzard's mana/rage/energy colours. Off: XIUI's colours.", true)
  Checkbox(cat, db.look, "hpBands", "Health changes colour as it drops", "XIUI's red, orange and yellow steps.", true)
  Checkbox(cat, db.look, "rounded", "Rounded corners", "Softly rounded corners on every ForeverXI window.", true)
  Checkbox(cat, db.look, "shine", "Shine on bars", "The light gradient over the fills.", true)


  ---- Sizes
  cat = Sub("Sizes")
  -- One size slider per frame, multiplied with the global scale.
  local frames = {
    { "player", "Player bar size" }, { "playerCast", "Your cast bar size" },
    { "target", "Target bar size" }, { "targetCast", "Target cast bar size" },
    { "tot", "Target of target size" }, { "party", "Party list size" },
    { "raid", "Raid list size" }, { "xp", "EXP bar size" },
    { "enemy", "Enemy list size" }, { "menu", "Menu size" },
    { "totems", "Totem bar size" }, { "swing", "Swing timer size" },
    { "notify", "Notification size" }, { "loot", "Treasure pool size" }, { "reminders", "Buff reminder size" }, { "nameplates", "XI nameplate size" },
  }
  for _, info in ipairs(frames) do
    local key, label = info[1], info[2]
    local s = Settings.RegisterAddOnSetting(cat, "ForeverXI_Scale_" .. key, key, db.frameScale,
      Settings.VarType.Number, label, 1)
    local o = Settings.CreateSliderOptions(0.5, 2, 0.05)
    if MinimalSliderWithSteppersMixin and MinimalSliderWithSteppersMixin.Label then
      o:SetLabelFormatter(MinimalSliderWithSteppersMixin.Label.Right, function(v) return ("%.2f"):format(v) end)
    end
    Settings.CreateSlider(cat, s, o, "Multiplied with the global scale.")
    s:SetValueChangedCallback(Changed(false))
  end


  ---- Player & target
  cat = Sub("Player & target")
  Checkbox(cat, m, "player", "Player bar", "Your HP and power bars.", true)
  Checkbox(cat, m, "target", "Target bar", "Your target's name and HP.", true)
  Checkbox(cat, m, "playerCast", "Your cast bar", nil, true)
  Checkbox(cat, m, "targetCast", "Target cast bar", "May stay empty on Forever if target casts are hidden from addons.", true)
  Checkbox(cat, m, "tot", "Target of target", "Who your target is attacking, right of the target bar. Click it to target them.", true)
  Checkbox(cat, m, "enemy", "Enemy list", "The mobs you and your group are fighting, by the target bar. Needs enemy nameplates on (V).", true)
  Checkbox(cat, db.target, "threatColors", "Threat colours on the target bar",
    "Green safe, yellow careful, red it's on you. As a tank: green you have it, yellow losing it, red lost it.", false)
  Checkbox(cat, db.target, "alwaysTank", "Always use tank threat colours",
    "Otherwise tank colours are used only when your group role is Tank.", false)
  Checkbox(cat, db.target, "auras", "Buffs and debuffs over the target bar", "Drawn by the game, so they keep working in combat.", true)
  Checkbox(cat, db.target, "showDebuffs", "Target debuffs", nil, false)
  Checkbox(cat, db.target, "showBuffs", "Target buffs", nil, false)
  Checkbox(cat, db.target, "onlyMine", "Only my debuffs on the target", nil, false)
  Checkbox(cat, db.target, "mobInfo", "Mob info on the target bar", "Level in the game's difficulty colour, elite or rare, and creature type.", false)

  ---- Party & raid
  cat = Sub("Party & raid")
  Checkbox(cat, m, "party", "Party list", nil, true)
  Checkbox(cat, m, "raid", "Raid list", "Other raid groups, on the right.", true)
  Checkbox(cat, db.party, "showSolo", "Show party list when solo", nil, true)
  local p = db.party
  Checkbox(cat, p, "auras", "Buffs and debuffs on the party list", "Drawn by the game, so they keep working in combat.", true)
  Checkbox(cat, p, "showBuffs", "Party buffs", nil, false)
  Checkbox(cat, p, "showDebuffs", "Party debuffs", "Coloured border: blue magic, green poison, purple curse, brown disease.", false)
  Checkbox(cat, p, "onlyMyBuffs", "Only buffs I cast", nil, false)
  Checkbox(cat, p, "onlyDispellable", "Only debuffs I can remove", nil, false)
  Checkbox(cat, p, "auraTimers", "Countdown numbers on buff icons", nil, false)
  Checkbox(cat, p, "auraInside", "Buffs and debuffs under the name",
    "A line under each name: buffs from the left, debuffs from the right. Off: beside the party list, timer under each icon. Needs a /reload.", true)
  Checkbox(cat, p, "auraWindow", "Window behind the buff icons", "An XI window behind the icons beside the party list.", false)
  Checkbox(cat, p, "pets", "Pets on the party list", "Each pet on the same line as its owner. The party window slides over to make room when someone has a pet out.", true)
  Checkbox(cat, p, "rangeFade", "Dim party members out of range", nil, false)
  Checkbox(cat, p, "flip", "Flip sides", "Pets left of the party window and the buff/debuff window right.", false)
  Checkbox(cat, db.raid, "hideOwnGroup", "Leave my group out of the raid list", "It's already in the party list.", false)


  ---- Minimap & gold
  cat = Sub("Minimap & gold")
  do
    local s = Settings.RegisterAddOnSetting(cat, "ForeverXI_MapScale", "scale", db.map, Settings.VarType.Number, "Minimap size", 1)
    local o = Settings.CreateSliderOptions(0.5, 2, 0.05)
    if MinimalSliderWithSteppersMixin and MinimalSliderWithSteppersMixin.Label then
      o:SetLabelFormatter(MinimalSliderWithSteppersMixin.Label.Right, function(v) return ("%.2f"):format(v) end)
    end
    Settings.CreateSlider(cat, s, o, "The minimap with its XI window, zone strip and gold strip. Move it in Edit Mode.")
    s:SetValueChangedCallback(Changed(false))
    local b = Settings.RegisterAddOnSetting(cat, "ForeverXI_MapButtons", "buttonSize", db.map, Settings.VarType.Number, "Minimap button size", 22)
    local bo = Settings.CreateSliderOptions(14, 36, 1)
    if MinimalSliderWithSteppersMixin and MinimalSliderWithSteppersMixin.Label then
      bo:SetLabelFormatter(MinimalSliderWithSteppersMixin.Label.Right, function(v) return ("%d px"):format(v) end)
    end
    Settings.CreateSlider(cat, b, bo, "The addon buttons along the map's edge.")
    b:SetValueChangedCallback(Changed(false))
  end

  Checkbox(cat, m, "gold", "Gold tracker", "Your gold on a strip on top of the minimap, with this session's change. Hover it for gold per hour and every character.", true)
  Checkbox(cat, db.goldTracker, "onXP", "Gold under the EXP bar instead", "Puts the gold line back under the EXP bar.", true)
  Checkbox(cat, db.goldTracker, "showRate", "Show gold per hour", nil, false)
  Checkbox(cat, db.goldTracker, "bags", "Bag slots next to your gold", "Used / total bag slots on the gold strip (and the EXP bar gold line): orange at 5 or fewer free, red at 2 or fewer.", false)
  Checkbox(cat, db.map, "skin", "XI minimap", "Minimap and zone name in the XI window.", true)
  Checkbox(cat, db.map, "square", "Square minimap", nil, true)
  Checkbox(cat, db.map, "buttonColumn", "Minimap buttons along the map edge", "Blizzard's and your addons' minimap buttons, squared off and lined up down the map's left edge. Turning it off needs a /reload.", true)
  Checkbox(cat, db.map, "coords", "Coordinates under the map", "On the strip with the zone and clock.", false)

  ---- EXP bar & notifications
  cat = Sub("EXP bar & notifications")
  Checkbox(cat, m, "xp", "EXP bar", "Experience with rested, quests ready to hand in, XP per hour and time to level.", true)
  Checkbox(cat, m, "notify", "Notifications", "Small XI toasts for loot, gold, XP, reputation and party invites. Move them with /fxi move.", true)
  Checkbox(cat, db.notify, "loot", "Toast: items you loot", nil, false)
  Checkbox(cat, db.notify, "gold", "Toast: gold you pick up", nil, false)
  Checkbox(cat, db.notify, "xp", "Toast: XP", nil, false)
  Checkbox(cat, db.notify, "rep", "Toast: reputation", nil, false)
  Checkbox(cat, db.notify, "invites", "Toast: party invites", nil, false)
  Checkbox(cat, db.notify, "growUp", "Toasts stack upward", nil, false)
  Checkbox(cat, m, "loot", "Treasure pool", "Group loot rolls in one XI window with Need/Greed/Pass, instead of Blizzard's popups.", true)
  Checkbox(cat, db.xp, "hideAtMax", "Hide the EXP bar at max level", nil, false)
  Checkbox(cat, db.xp, "showQuest", "Show XP from finished quests", "Gold stretch on the bar for quests ready to hand in.", false)
  Checkbox(cat, db.xp, "showRate", "Show XP per hour and time to level", nil, false)

  ---- Action bars & menu
  cat = Sub("Action bars & menu")
  Checkbox(cat, db.bars, "enabled", "XI action bars", "XI window behind every action bar, sized to its buttons.", true)
  Checkbox(cat, db.bars, "window", "Window behind the action bars", "The XI window behind each bar. Off: just the buttons.", false)
  Checkbox(cat, db.bars, "hideArt", "Hide Blizzard action bar art", "The end caps and border art on the main bar. Turning it back on needs a /reload.", true)
  Checkbox(cat, db.bars, "highlight", "Light up bar 2 while Shift is held", nil, true)
  Checkbox(cat, db.bars, "dim", "Dim bar 1 while Shift is held", nil, false)
  Checkbox(cat, db.bars, "glowBase", "Outline bar 1 when no key is held", nil, false)
  Checkbox(cat, db, "hideBagBar", "Hide Blizzard bag bar", "B and your bag keys still open bags. Turning it back on needs a /reload.", true)
  Checkbox(cat, db, "menuSkin", "XI text menu", "Replaces Blizzard's menu bar with an XI window of text entries. Move it with /fxi move.", true)
  Checkbox(cat, db.menu, "vertical", "XI menu as a column", "FFXI's main menu layout. Needs a /reload.", true)
  Checkbox(cat, db.menu, "icons", "XI menu icons", "Icon tiles with the name on mouse over. Off: text entries. Needs a /reload.", true)
  Checkbox(cat, db.menu, "bagCount", "Free bag slots on the Bags button", "White, orange at 5 or fewer, red at 2 or fewer.", false)
  -- One box per menu button (ticked = shown).
  db.menu.hide = db.menu.hide or {}
  db.menu.show = db.menu.show or {}
  local menuMod = ns.modules.MenuSkin
  for _, spec in ipairs(menuMod and menuMod.ENTRIES or {}) do
    local name = spec[1]
    do
      db.menu.show[name] = not db.menu.hide[name]
      local s = Settings.RegisterAddOnSetting(cat, "ForeverXI_MenuShow_" .. name, name, db.menu.show,
        Settings.VarType.Boolean, "Menu button: " .. name, true)
      Settings.CreateCheckbox(cat, s, "Untick to leave this button off the XI menu. Needs a /reload.")
      s:SetValueChangedCallback(function(_, value)
        db.menu.hide[name] = not value or nil
        ns.Print("change saved. Type /reload to apply it.")
      end)
    end
  end
  Checkbox(cat, db.bags, "skin", "Baganator in the XI look", "Navy XI window, square item tiles with a thin quality edge, XI buttons. Baganator still does the sorting and categories. Needs a /reload.", true)
  Checkbox(cat, db.bags, "freeLine", "Free slots under the bags", "\"12 / 42 free\" at the bottom of Baganator's backpack. Needs a /reload.", true)

  ---- Chat & damage meter
  cat = Sub("Chat & damage meter")
  Checkbox(cat, m, "chat", "Chat window skin", "Turning it off needs a /reload.", true)
  Checkbox(cat, db.meter, "skin", "XI damage meter", "The built-in damage meter in the XI window. Turning it off needs a /reload.", true)
  Checkbox(cat, db.chat, "stack", "Stack the combat log on top of General",
    "Same width, height and text size, like FFXI's two chat logs. Move and size General in Edit Mode; the combat log follows.", false)
  do
    local fs = Settings.RegisterAddOnSetting(cat, "ForeverXI_ChatFont", "fontSize", db.chat, Settings.VarType.Number,
      "Chat text size", 13)
    local o = Settings.CreateSliderOptions(9, 20, 1)
    if MinimalSliderWithSteppersMixin and MinimalSliderWithSteppersMixin.Label then
      o:SetLabelFormatter(MinimalSliderWithSteppersMixin.Label.Right, function(v) return ("%d"):format(v) end)
    end
    Settings.CreateSlider(cat, fs, o, "Text size in every chat window.")
    fs:SetValueChangedCallback(function() if ns.ChatLayout then ns.ChatLayout() end end)
    -- Width and height of General; the stacked combat log copies them.
    for _, info in ipairs({ { "width", "Chat window width", 200, 1000, 10, 430 }, { "height", "Chat window height", 60, 600, 5, 120 } }) do
      local s = Settings.RegisterAddOnSetting(cat, "ForeverXI_Chat_" .. info[1], info[1], db.chat, Settings.VarType.Number,
        info[2], info[6])
      local so = Settings.CreateSliderOptions(info[3], info[4], info[5])
      if MinimalSliderWithSteppersMixin and MinimalSliderWithSteppersMixin.Label then
        so:SetLabelFormatter(MinimalSliderWithSteppersMixin.Label.Right, function(v) return ("%d"):format(v) end)
      end
      Settings.CreateSlider(cat, s, so, "Sizes General and the combat log stacked on it together. Until you move this, Edit Mode's size is kept.")
      s:SetValueChangedCallback(function()
        db.chat.sizeOn = true
        if ns.ChatLayout then ns.ChatLayout() end
      end)
    end
  end

  ---- Shaman
  cat = Sub("Shaman")
  Checkbox(cat, m, "totems", "Totem bar", "Your four totems with timers. Right-click one to take it down.", true)
  Checkbox(cat, db.totems, "anyClass", "Totem bar on every class", "Off: shamans only.", true)
  Checkbox(cat, m, "swing", "Swing timer", "A slim bar that fills from one melee swing to the next.", true)
  Checkbox(cat, db.swing, "alwaysShow", "Keep the swing timer visible out of combat", nil, false)
  Checkbox(cat, m, "reminders", "Buff reminder", "Shows Lightning Shield or your weapon imbue when they're missing or running out, right of your cast bar. Move it with /fxi move.", true)
  Checkbox(cat, db.reminders, "shield", "Remind: Lightning Shield", nil, false)
  Checkbox(cat, db.reminders, "imbue", "Remind: weapon imbue (missing or under 2 min)", nil, false)
  Checkbox(cat, db.reminders, "hideResting", "No reminders in cities and inns", nil, false)

  ---- Nameplates & tooltip
  cat = Sub("Nameplates & tooltip")
  Checkbox(cat, db.plater, "partyBars", "Plater: health bars on party members", "Your party and raid get a class-coloured health bar on their nameplate; other friendly players stay name only.", false)
  Checkbox(cat, m, "nameplates", "XI nameplates (instead of Plater)",
    "ForeverXI's own nameplates in the XI look: enemy bars with health %, threat colours, grey for claimed mobs, cast bars, and friendly names by relation with class icons. Only runs while Plater is turned off in the AddOns list. Needs a /reload.", true)
  Checkbox(cat, db.nameplates, "partyBars", "XI nameplates: green bars on party members", nil, false)
  Checkbox(cat, db.nameplates, "hidePets", "XI nameplates: no names on pets, minions and totems", nil, false)
  Checkbox(cat, db.nameplates, "castBars", "XI nameplates: enemy cast bars", nil, false)
  Checkbox(cat, db.nameplates, "hideFloating", "XI nameplates: hide the game's far-away names", "Past nameplate range the game shows plain floating names. On: nothing shows until the XI plate does.", false)
  -- Size sliders right here, so they're next to the nameplate switches.
  do
    local function NPSlider(variable, key, tbl, label, default, lo, hi, step, fmt, tip)
      local s = Settings.RegisterAddOnSetting(cat, variable, key, tbl, Settings.VarType.Number, label, default)
      local so = Settings.CreateSliderOptions(lo, hi, step)
      if MinimalSliderWithSteppersMixin and MinimalSliderWithSteppersMixin.Label then
        so:SetLabelFormatter(MinimalSliderWithSteppersMixin.Label.Right, function(v) return fmt:format(v) end)
      end
      Settings.CreateSlider(cat, s, so, tip)
      s:SetValueChangedCallback(Changed(false))
    end
    NPSlider("ForeverXI_NP_Size", "nameplates", db.frameScale, "XI nameplates: size", 1, 0.5, 2, 0.05, "%.2f",
      "Bars, names and icons together. The same slider as XI nameplate size under Sizes.")
    NPSlider("ForeverXI_NP_NameSize", "nameSize", db.nameplates, "XI nameplates: name text size", 13, 9, 20, 1, "%d",
      "Just the names, on top of the size above.")
    NPSlider("ForeverXI_NP_Distance", "distance", db.nameplates, "XI nameplates: distance (yards)", 41, 0, 60, 1, "%d",
      "How far away plates show. Past this the game draws its own plain floating names. The game caps this (often at 41); 0 leaves the game's own setting.")
  end
  Checkbox(cat, db.plater, "tapGrey", "Plater: grey for mobs claimed by someone else", "A mob another player or group tagged first shows grey instead of red.", false)
  Checkbox(cat, db.plater, "nameColors", "Plater: names by who they are, with class icons",
    "Party green, your faction blue, the other faction orange, attackable players red, and a class icon in front of every player's name. Needs a /reload to turn off fully.", false)
  Checkbox(cat, db.tooltip, "move", "Move the tooltip", "The game's tooltip gets its own spot (drag it with /fxi move) instead of the bottom-right corner over your party list. Turning it off needs a /reload.", true)
  Checkbox(cat, db.tooltip, "cursor", "Tooltip follows the mouse", "Instead of the fixed spot.", false)
  Checkbox(cat, db.plater, "skin", "Easier-to-read Plater",
    "Bigger outlined names, names only on friendly players, bigger enemy bars with health %, in the XI look. Written into Plater once; /fxi plater undo puts your old settings back.", true)


  ---- Blizzard frames
  cat = Sub("Blizzard frames")
  local h = db.hideBlizzard
  Checkbox(cat, h, "player", "Hide Blizzard player frame", nil, true)
  Checkbox(cat, h, "target", "Hide Blizzard target frame", nil, true)
  Checkbox(cat, h, "cast", "Hide Blizzard cast bar", nil, true)
  Checkbox(cat, h, "party", "Hide Blizzard party frames", nil, true)
  Checkbox(cat, h, "raid", "Hide Blizzard raid frames", "The raid side panel (ready check, markers) stays.", true)
  Checkbox(cat, h, "xp", "Hide Blizzard XP and reputation bar", "Only while the ForeverXI EXP bar is on.", true)
  Checkbox(cat, h, "totems", "Hide Blizzard totem frame", "Only while the ForeverXI totem bar is on.", true)


  Settings.RegisterAddOnCategory(main)
  return main
end

function M:Init()
  if not (Settings and Settings.RegisterVerticalLayoutCategory and Settings.RegisterAddOnSetting) then
    return
  end
  local ok, cat = pcall(Build)
  if ok then
    category = cat
  else
    ns.Print("the Settings panel didn't build on this client (%s). Use /fxi commands for now.", tostring(cat))
  end
end

local function Help()
  ns.Print("commands:")
  print("  /fxi  - open options")
  print("  /fxi move  - drag frames (also on while Edit Mode is open)")
  print("  /fxi preview  - show a pretend full party and raid (also on with /fxi move)")
  print("  /fxi reset  - put every frame back to the default layout")
  print("  /fxi compact  - toggle compact mode")
  print("  /fxi scale 1.2  - size of everything; /fxi scale party 1.1  - one frame")
  print("  /fxi chat  - re-stack the combat log on General and even out text size")
  print("  /fxi chat 430 120  - size both chat windows (width height); /fxi chat off - back to Edit Mode's size")
  print("  /fxi map  - line the minimap buttons up again and show the minimap layout")
  print("  /fxi hide  - hide the box under the mouse (e.g. another addon's coordinates); /fxi unhide to bring them back")
  print("  /fxi meter  - list what the damage meter is made of (to fit its skin)")
  print("  /fxi plater - set Plater up to be easier to read again; /fxi plater undo puts your old settings back")
  print("  /fxi check  - test what Forever lets addons read (run it in combat too)")
end

SLASH_FOREVERXI1 = "/fxi"
SLASH_FOREVERXI2 = "/foreverxi"
SlashCmdList.FOREVERXI = function(msg)
  msg = (msg or ""):lower():match("^%s*(.-)%s*$")
  if msg == "move" or msg == "unlock" or msg == "lock" then
    ns.Movers.Toggle()
  elseif msg == "reset" then
    if InCombatLockdown() then ns.Print("not in combat.") return end
    ns.Movers.ResetAll()
    ns.Print("frames reset to the default layout.")
  elseif msg == "compact" then
    ns.db.compact = not ns.db.compact
    ns.ForEachModule("Relayout")
    ns.Print("compact mode %s.", ns.db.compact and "on" or "off")
  elseif msg:match("^scale") then
    local what, value = msg:match("^scale%s+(%a*)%s*([%d%.]+)$")
    value = tonumber(value)
    if not value or value < 0.3 or value > 3 then
      ns.Print("usage: /fxi scale 1.2  or  /fxi scale party 1.1 (player, playercast, target, targetcast, tot, party, raid, xp, enemy, menu, totems, swing, notify, loot)")
      return
    end
    local keys = { player = "player", playercast = "playerCast", target = "target", targetcast = "targetCast", tot = "tot", party = "party", raid = "raid", xp = "xp", enemy = "enemy", menu = "menu", totems = "totems", swing = "swing", notify = "notify", loot = "loot" }
    if what == nil or what == "" then
      ns.db.scale = value
    elseif keys[what] then
      ns.db.frameScale[keys[what]] = value
    else
      ns.Print("unknown frame '%s'.", what)
      return
    end
    ns.ApplyScale()
    ns.Print("scale set.")
  elseif msg == "preview" or msg == "test" then
    ns.SetPreview(not ns.previewOn)
  elseif msg:match("^chat") then
    local w, h = msg:match("^chat%s+(%d+)%s+(%d+)$")
    if msg:match("^chat%s+off$") then
      ns.db.chat.sizeOn = false
      ns.Print("chat size back to Edit Mode's. /reload to see it.")
      return
    end
    if w then
      ns.db.chat.width, ns.db.chat.height, ns.db.chat.sizeOn = tonumber(w), tonumber(h), true
    end
    if ns.ChatLayout then ns.ChatLayout(true) end
  elseif msg == "map" then
    local ms = ns.modules.MapSkin
    if ms and ms.Dump then ms.Dump() end
  elseif msg == "hide" then
    ns.HideUnderMouse()
  elseif msg == "unhide" then
    ns.UnhideAll()
  elseif msg == "meter" then
    local ms = ns.modules.MeterSkin
    if ms and ms.Dump then ms.Dump() end
  elseif msg == "plater" or msg == "plater undo" then
    local ps = ns.modules.PlaterSkin
    if ps then
      if msg == "plater undo" then ps.Undo() else ns.db.plater.skin = true ps.Apply(true) end
    end
  elseif msg == "check" then
    ns.Check()
  elseif msg == "help" then
    Help()
  else
    if category and Settings.OpenToCategory then
      local ok = pcall(Settings.OpenToCategory, category:GetID())
      if ok then return end
    end
    Help()
  end
end
