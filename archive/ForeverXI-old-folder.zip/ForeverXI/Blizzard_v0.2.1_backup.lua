-- Put Blizzard's own frames away where ForeverXI replaces them.
--
-- Protected frames (player, target, target-of-target) and Edit Mode managed
-- frames are faded and made deaf, never hidden or re-parented: hiding them
-- from addon code spreads taint into Edit Mode on Forever. Party and raid
-- containers are re-parented under a hidden frame, because Blizzard re-shows
-- them on every roster change. Turning an option back on needs /reload.
local _, ns = ...

local M = ns.AddModule("Blizzard")

local hider = CreateFrame("Frame")
hider:Hide()
local faded = {}

local function KeepFaded(frame)
  if faded[frame] and frame:GetAlpha() > 0 then frame:SetAlpha(0) end
end

local function Fade(frame)
  if type(frame) ~= "table" or not frame.SetAlpha then return end
  if frame.UnregisterAllEvents then pcall(frame.UnregisterAllEvents, frame) end
  frame:SetAlpha(0)
  if frame.EnableMouse then pcall(frame.EnableMouse, frame, false) end
  if not faded[frame] then
    faded[frame] = true
    hooksecurefunc(frame, "SetAlpha", KeepFaded)
    if frame.HookScript then frame:HookScript("OnShow", KeepFaded) end
  end
end

local function Stash(frame)
  if type(frame) ~= "table" then return end
  if frame.UnregisterAllEvents then pcall(frame.UnregisterAllEvents, frame) end
  local hide = rawget(frame, "HideBase") or frame.Hide
  pcall(hide, frame)
  pcall(frame.SetParent, frame, hider)
end

local function Deafen(frame)
  if type(frame) == "table" and frame.UnregisterAllEvents then
    pcall(frame.UnregisterAllEvents, frame)
  end
end

local function HideAll()
  local h = ns.db.hideBlizzard
  if h.player and ns.db.modules.player then
    Fade(PlayerFrame)
  end
  if h.target and ns.db.modules.target then
    Fade(TargetFrame)
    Fade(TargetFrameToT)
  end
  if h.cast and ns.db.modules.playerCast then
    for _, name in ipairs({ "PlayerCastingBarFrame", "CastingBarFrame", "GamepadPlayerCastingBarFrame" }) do
      Fade(_G[name])
    end
  end
  if h.party and ns.db.modules.party then
    if PartyFrame then
      if PartyFrame.PartyMemberFramePool then
        for member in PartyFrame.PartyMemberFramePool:EnumerateActive() do Deafen(member) end
      end
      for i = 1, 4 do Deafen(PartyFrame["MemberFrame" .. i]) end
      Stash(PartyFrame)
    end
    Stash(CompactPartyFrame)
  end
  if h.raid and ns.db.modules.raid then
    -- Only the frames. The side panel (ready check, markers) stays.
    Stash(CompactRaidFrameContainer)
  end
end

function M:Init()
  ns.AfterCombat("blizzard", HideAll)
end

-- The raid frames load on demand.
ns.On("ADDON_LOADED", function(_, name)
  if name == "Blizzard_CompactRaidFrames" and ns.db and ns.db.hideBlizzard.raid and ns.db.modules.raid then
    ns.AfterCombat("blizzardRaid", function() Stash(CompactRaidFrameContainer) end)
  end
end)
