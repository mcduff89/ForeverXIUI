-- Blizzard's micro menu and bag bar, sat in an XI navy window so they match
-- the rest. Only a panel is drawn BEHIND them: the Blizzard buttons are not
-- re-parented, moved or clicked for, because on Forever touching those from
-- addon code taints the game's windows. Place and size the two bars in
-- Edit Mode (Micro Menu and Bag Bar); the window follows them.
local _, ns = ...

local M = ns.AddModule("MenuSkin")

local function Behind(target)
  if type(target) ~= "table" or not target.GetCenter then return nil end
  local p = CreateFrame("Frame", nil, UIParent)
  p:SetFrameStrata("BACKGROUND")
  p:SetPoint("TOPLEFT", target, "TOPLEFT", -5, 5)
  p:SetPoint("BOTTOMRIGHT", target, "BOTTOMRIGHT", 5, -5)
  ns.Style.Panel(p, 0.88)
  -- Follow the bar's own visibility (vehicles, pet battles, Edit Mode).
  if target.HookScript then
    target:HookScript("OnShow", function() p:Show() end)
    target:HookScript("OnHide", function() p:Hide() end)
  end
  p:SetShown(target:IsShown())
  return p
end

function M:Init()
  if not ns.db.menuSkin then return end
  self.micro = Behind(MicroMenuContainer or MicroMenu or MicroButtonAndBagsBar)
  self.bags = Behind(BagsBar)
end
