-- ForeverXI core: saved settings, events, the out-of-combat queue and the
-- module list. Everything else hangs off the shared namespace `ns`.
local ADDON, ns = ...

ns.name = ADDON
ns.version = "0.6.5"
ns.DB_VERSION = 5

-- Defaults. New keys are filled in on load, so adding one here is safe for
-- existing saved settings. Renaming or removing one needs a step in Migrate.
ns.defaults = {
  dbVersion = 5,
  scale = 1,
  -- Per-frame size on top of the global scale.
  frameScale = { player = 1, playerCast = 1, target = 1, targetCast = 1, tot = 1, party = 1, raid = 1, xp = 1, enemy = 1, menu = 1, totems = 1, swing = 1 },
  compact = false,
  modules = {
    player = true,
    target = true,
    playerCast = true,
    targetCast = true,
    tot = true,          -- target of target
    xp = true,           -- EXP bar
    enemy = true,        -- enemy list by the target bar
    party = true,
    raid = true,
    chat = true,
    totems = true,       -- totem bar (shamans)
    swing = true,        -- swing timer
    gold = true,         -- gold on the EXP bar
  },
  hideBlizzard = {
    player = true,
    target = true,
    cast = true,
    party = true,
    raid = true,
    xp = true,           -- Blizzard's XP/reputation bar (only while ForeverXI's EXP bar is on)
    totems = true,       -- Blizzard's totem frame by the player frame (while the totem bar is on)
  },
  totems = {
    anyClass = false,    -- show the totem bar on non-shamans too
  },
  swing = {
    alwaysShow = false,  -- keep the swing bar faintly visible out of combat
  },
  goldTracker = {
    showRate = true,     -- gold per hour beside the session change
  },
  meter = {
    skin = true,         -- the built-in damage meter in an XI window
  },
  target = {
    threatColors = true, -- colour the target bar by your threat on it
    alwaysTank = false,  -- use tank colours even without the tank role
    mobInfo = true,      -- "Lv 18 Elite Beast" on the target bar
  },
  xp = {
    hideAtMax = true,    -- hide the EXP bar at level 60
    showQuest = true,    -- gold stretch for quests ready to hand in
    showRate = true,     -- XP per hour and time to level
  },
  menuSkin = true,       -- XI text menu in place of Blizzard's micro menu
  menu = {
    vertical = false,    -- a column of entries (FFXI's main menu) instead of a row
    icons = true,        -- icon tiles, name shown on mouse over (off: text entries)
  },
  map = {
    skin = true,         -- minimap in an XI window
    square = true,       -- square map (off: Blizzard's round one, inside the window)
    buttonColumn = true, -- line up the buttons around the map along its left edge
    coords = true,       -- your coordinates on the strip under the map
  },
  hideBagBar = true,
  look = {
    classicColors = true, -- WoW red health and Blizzard power colours (off = XIUI colours)
    hpBands = false,      -- XIUI's red/orange/yellow steps as health drops
    shine = false,        -- the light gradient over bar fills
    rounded = true,       -- rounded corners on every window
  },
  bars = {
    enabled = true,      -- XI window behind action bars 1-3
    highlight = false,   -- light up bar 2 while Shift is held (off: Zac dropped the idea)
    dim = true,          -- dim bar 1 while Shift is held
    dimAlpha = 0.55,
    glowBase = false,    -- also outline bar 1 when no modifier is held
    hideArt = true,      -- fade Blizzard's end caps and border art on the bars
  },
  chat = {
    stack = true,        -- combat log window stacked on top of General, same size
    fontSize = 13,       -- one text size for every chat window
    gap = 30,            -- room for General's tabs between the two windows
    sizeOn = false,      -- true once a chat size slider is used (until then Edit Mode's size is kept)
    width = 430,
    height = 120,
  },     -- fade out Blizzard's bag bar (B still opens bags)
  party = {
    showSolo = true,     -- XIUI "show party list when solo"
    auras = true,        -- buff and debuff icons beside each member
    showBuffs = true,
    showDebuffs = true,
    onlyMyBuffs = false, -- only buffs you cast
    onlyDispellable = false, -- only debuffs you can remove
    auraTimers = true,   -- countdown numbers on the icons (the swipe always shows)
    auraSize = 16,
    auraWindow = false,  -- an XI window behind the icons beside the list
    auraCols = 6,        -- icons per line in the window beside the party list
    auraInside = false,  -- icons on a line under the name (off: their own window beside the list)
    pets = true,         -- each member's pet on their line
    flip = false,        -- false: icons left, pets right; true: the other way round
  },
  raid = {
    hideOwnGroup = true, -- your own group is already in the party list
  },
  positions = {},        -- filled by the movers; empty means "use the default"
}

local function FillDefaults(dst, src)
  for k, v in pairs(src) do
    if type(v) == "table" then
      if type(dst[k]) ~= "table" then dst[k] = {} end
      FillDefaults(dst[k], v)
    elseif dst[k] == nil then
      dst[k] = v
    end
  end
end

-- One step per saved-settings version. Nothing to migrate yet (version 1).
local function Migrate(db)
  db.dbVersion = tonumber(db.dbVersion) or 1
  -- 2 (0.1.4): the menu window turned out not to help; off for everyone.
  if db.dbVersion < 2 then
    db.menuSkin = false
    db.dbVersion = 2
  end
  -- 3 (0.4.0): Zac asked for every Blizzard piece in the XI navy, the menu too.
  if db.dbVersion < 3 then
    db.menuSkin = true
    db.dbVersion = 3
  end
  -- 4 (0.4.1): Zac's party layout: timers on, icons beside the window (not
  -- under the name), 14px icons. Pets moved to the right (flip now means left).
  if db.dbVersion < 4 then
    if type(db.party) == "table" then
      db.party.auraTimers = true
      db.party.auraInside = false
      db.party.auraSize = 14
      db.party.flip = false
    end
    db.dbVersion = 4
  end
  -- 5 (0.5.1): no window behind the icons, bigger icons with the timer under each.
  if db.dbVersion < 5 then
    if type(db.party) == "table" then
      db.party.auraWindow = false
      db.party.auraSize = 16
    end
    db.dbVersion = 5
  end
end

function ns.Print(msg, ...)
  if select("#", ...) > 0 then msg = msg:format(...) end
  DEFAULT_CHAT_FRAME:AddMessage("|cff78c4eeForeverXI|r " .. tostring(msg))
end

-- pcall that only reports success and the first result.
function ns.Try(fn, ...)
  local ok, a, b, c, d = pcall(fn, ...)
  if ok then return true, a, b, c, d end
  return false
end

-- True only for a value we are allowed to read. Use type(), never `== nil`
-- or `if v`, on anything that might be secret: those can throw on Forever.
function ns.Readable(v)
  if type(v) == "nil" then return false end
  if issecretvalue then
    local ok, secret = pcall(issecretvalue, v)
    if not ok or secret then return false end
  end
  return true
end

-- A plain true/false from a call that might return a secret boolean.
function ns.Bool(fn, ...)
  local ok, v = pcall(fn, ...)
  if not ok or not ns.Readable(v) then return nil end
  return v and true or false
end

---------------------------------------------------------------------------
-- Events
---------------------------------------------------------------------------
local driver = CreateFrame("Frame")
local handlers = {}

function ns.On(event, fn)
  if not handlers[event] then
    handlers[event] = {}
    driver:RegisterEvent(event)
  end
  table.insert(handlers[event], fn)
end

driver:SetScript("OnEvent", function(_, event, ...)
  local list = handlers[event]
  if not list then return end
  for i = 1, #list do
    local ok, err = pcall(list[i], event, ...)
    if not ok then
      geterrorhandler()(err)
    end
  end
end)

---------------------------------------------------------------------------
-- Out-of-combat queue: secure frames can't be shown, moved or rebuilt while
-- InCombatLockdown() is true, so those jobs wait for PLAYER_REGEN_ENABLED.
---------------------------------------------------------------------------
local queued, queueOrder = {}, {}

function ns.AfterCombat(key, fn)
  if not InCombatLockdown() then
    fn()
    return true
  end
  if not queued[key] then table.insert(queueOrder, key) end
  queued[key] = fn
  return false
end

ns.On("PLAYER_REGEN_ENABLED", function()
  local order = queueOrder
  queueOrder = {}
  for _, key in ipairs(order) do
    local fn = queued[key]
    queued[key] = nil
    if fn then
      local ok, err = pcall(fn)
      if not ok then geterrorhandler()(err) end
    end
  end
end)

---------------------------------------------------------------------------
-- Modules. Each file adds itself with ns.AddModule(name, table) and gets
-- :Init() at login, in file order.
---------------------------------------------------------------------------
ns.modules = {}
ns.moduleOrder = {}

function ns.AddModule(name, mod)
  mod = mod or {}
  mod.name = name
  ns.modules[name] = mod
  table.insert(ns.moduleOrder, name)
  return mod
end

function ns.ForEachModule(method, ...)
  for _, name in ipairs(ns.moduleOrder) do
    local mod = ns.modules[name]
    if mod[method] then
      local ok, err = pcall(mod[method], mod, ...)
      if not ok then geterrorhandler()(err) end
    end
  end
end

ns.On("ADDON_LOADED", function(_, name)
  if name ~= ADDON then return end
  ForeverXIDB = ForeverXIDB or {}
  Migrate(ForeverXIDB)
  FillDefaults(ForeverXIDB, ns.defaults)
  ForeverXIDB.dbVersion = ns.DB_VERSION
  ns.db = ForeverXIDB
end)

ns.On("PLAYER_LOGIN", function()
  ns.ForEachModule("Init")
  ns.ApplyScale()
  ns.Print("v%s loaded. /fxi for options, /fxi move to place frames.", ns.version)
end)

-- /fxi preview: pretend party, raid, target and casts, to lay things out.
function ns.SetPreview(on)
  if on and InCombatLockdown() then
    ns.Print("preview is out of combat only.")
    return
  end
  ns.previewOn = on and true or nil
  ns.ForEachModule("Preview", on and true or false)
  if on then
    ns.Print("preview on: pretend party, raid, target and casts. /fxi preview again to turn it off.")
  else
    ns.Print("preview off.")
  end
end

ns.On("PLAYER_REGEN_DISABLED", function()
  if ns.previewOn then ns.SetPreview(false) end
end)

-- Hover tooltip for a unit button (party, pets, raid, target of target).
function ns.UnitTooltip(frame)
  frame:HookScript("OnEnter", function(self)
    local unit = self.unit or self:GetAttribute("unit")
    if not unit or not UnitExists(unit) then return end
    if GameTooltip_SetDefaultAnchor then GameTooltip_SetDefaultAnchor(GameTooltip, self) else GameTooltip:SetOwner(self, "ANCHOR_RIGHT") end
    pcall(GameTooltip.SetUnit, GameTooltip, unit)
    GameTooltip:Show()
  end)
  frame:HookScript("OnLeave", function() GameTooltip:Hide() end)
end

-- Scale for every module root. Secure roots can't be rescaled in combat.
ns.roots = {}
function ns.AddRoot(frame, key)
  frame.fxiKey = key
  table.insert(ns.roots, frame)
end

function ns.ApplyScale()
  ns.AfterCombat("scale", function()
    local s = tonumber(ns.db and ns.db.scale) or 1
    local per = ns.db and ns.db.frameScale or {}
    for _, f in ipairs(ns.roots) do
      local k = tonumber(f.fxiKey and per[f.fxiKey]) or 1
      f:SetScale(math.max(0.3, s * k))
    end
    if ns.Movers then ns.Movers.ApplyAll() end
  end)
end
