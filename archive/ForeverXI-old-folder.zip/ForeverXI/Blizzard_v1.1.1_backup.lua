-- Put Blizzard's own frames away where ForeverXI replaces them.
--
-- Protected frames (player, target, target-of-target) and Edit Mode managed
-- frames are faded and made deaf, never hidden or re-parented: hiding them
-- from addon code spreads taint into Edit Mode on Forever. Party and raid
-- containers are re-parented under a hidden frame, because Blizzard re-shows
-- them on every roster change. Turning an option back on needs /reload.
local _, ns = ...

local M = ns.AddModule("Blizzard")

local hider = CreateFrame("Frame")
hider:Hide()
local faded = {}

local function KeepFaded(frame)
  if faded[frame] and frame:GetAlpha() > 0 then frame:SetAlpha(0) end
end

local function Fade(frame)
  if type(frame) ~= "table" or not frame.SetAlpha then return end
  if frame.UnregisterAllEvents then pcall(frame.UnregisterAllEvents, frame) end
  frame:SetAlpha(0)
  if frame.EnableMouse then pcall(frame.EnableMouse, frame, false) end
  if not faded[frame] then
    faded[frame] = true
    hooksecurefunc(frame, "SetAlpha", KeepFaded)
    if frame.HookScript then frame:HookScript("OnShow", KeepFaded) end
  end
end

local function Stash(frame)
  if type(frame) ~= "table" then return end
  if frame.UnregisterAllEvents then pcall(frame.UnregisterAllEvents, frame) end
  local hide = rawget(frame, "HideBase") or frame.Hide
  pcall(hide, frame)
  pcall(frame.SetParent, frame, hider)
end

local function Deafen(frame)
  if type(frame) == "table" and frame.UnregisterAllEvents then
    pcall(frame.UnregisterAllEvents, frame)
  end
end

-- The quest/objective tracker, while Polestar is on (it has its own). The
-- tracker holds clickable quest-item buttons, so it's hidden outright (not
-- just faded, which would leave invisible buttons to mis-click), only out of
-- combat, and hidden again whenever the game shows it.
local TRACKERS = { "ObjectiveTrackerFrame", "WatchFrame", "QuestWatchFrame" }
local trackerHooked = {}

local function PolestarOn()
  local f = (C_AddOns and C_AddOns.IsAddOnLoaded) or IsAddOnLoaded
  if not f then return false end
  local ok, on = pcall(f, "Polestar")
  return ok and on and true or false
end

local function WantTrackerHidden()
  local mode = ns.db.hideBlizzard.objectives
  if mode == "always" then return true end
  return mode ~= false and PolestarOn()
end

local function HideTrackers()
  if not WantTrackerHidden() then return end
  for _, name in ipairs(TRACKERS) do
    local f = _G[name]
    if type(f) == "table" and f.Hide then
      pcall(f.Hide, f)
      if not trackerHooked[f] then
        trackerHooked[f] = true
        hooksecurefunc(f, "Show", function()
          if WantTrackerHidden() then ns.AfterCombat("tracker:" .. name, function() pcall(f.Hide, f) end) end
        end)
      end
    end
  end
end
M.HideTrackers = HideTrackers

local function HideAll()
  local h = ns.db.hideBlizzard
  if h.player and ns.db.modules.player then
    Fade(PlayerFrame)
  end
  if h.target and ns.db.modules.target then
    Fade(TargetFrame)
    Fade(TargetFrameToT)
  end
  if h.cast and ns.db.modules.playerCast then
    for _, name in ipairs({ "PlayerCastingBarFrame", "CastingBarFrame", "GamepadPlayerCastingBarFrame" }) do
      Fade(_G[name])
    end
  end
  if h.party and ns.db.modules.party then
    if PartyFrame then
      if PartyFrame.PartyMemberFramePool then
        for member in PartyFrame.PartyMemberFramePool:EnumerateActive() do Deafen(member) end
      end
      for i = 1, 4 do Deafen(PartyFrame["MemberFrame" .. i]) end
      Stash(PartyFrame)
    end
    Stash(CompactPartyFrame)
  end
  if h.xp and ns.db.modules.xp then M.HideStatusBars() end
  HideTrackers()
  if h.raid and ns.db.modules.raid then
    -- Only the frames. The side panel (ready check, markers) stays.
    Stash(CompactRaidFrameContainer)
  end
end

---------------------------------------------------------------------------
-- Blizzard's XP and reputation bars (Edit Mode frames: faded, never hidden).
-- The game puts their alpha back to 1 by itself, without going through
-- SetAlpha in Lua, so the hook alone misses it: every bar inside each
-- container is faded too, and it's re-checked when XP or reputation
-- changes and twice a second while anything has crept back.
---------------------------------------------------------------------------
local statusFrames = {}

local function StatusFrames()
  wipe(statusFrames)
  local function add(f)
    if type(f) == "table" and f.SetAlpha then statusFrames[#statusFrames + 1] = f end
  end
  add(_G.MainStatusTrackingBarContainer)
  add(_G.SecondaryStatusTrackingBarContainer)
  local mgr = _G.StatusTrackingBarManager
  if type(mgr) == "table" then
    for _, c in ipairs(mgr.barContainers or {}) do
      add(c)
      for _, bar in pairs(c.bars or {}) do
        add(bar)
        if type(bar) == "table" then add(bar.ExhaustionTick) end
      end
    end
  end
  return statusFrames
end

local function Silence()
  for _, f in ipairs(StatusFrames()) do
    if f:GetAlpha() > 0 then f:SetAlpha(0) end
    if f.EnableMouse then pcall(f.EnableMouse, f, false) end
    if not faded[f] then
      faded[f] = true
      hooksecurefunc(f, "SetAlpha", KeepFaded)
      if f.HookScript then f:HookScript("OnShow", KeepFaded) end
    end
  end
end

function M.HideStatusBars()
  Silence()
  if M.statusWatch then return end
  local w = CreateFrame("Frame")
  for _, e in ipairs({ "PLAYER_XP_UPDATE", "UPDATE_EXHAUSTION", "PLAYER_LEVEL_UP", "UPDATE_FACTION",
    "PLAYER_ENTERING_WORLD", "PLAYER_UPDATE_RESTING" }) do
    pcall(w.RegisterEvent, w, e)
  end
  w:SetScript("OnEvent", function() C_Timer.After(0, Silence) end)
  local acc = 0
  w:SetScript("OnUpdate", function(_, dt)
    acc = acc + dt
    if acc < 0.5 then return end
    acc = 0
    for _, f in ipairs(statusFrames) do
      if f:GetAlpha() > 0 then f:SetAlpha(0) end
    end
  end)
  local mgr = _G.StatusTrackingBarManager
  if type(mgr) == "table" and type(mgr.UpdateBarsShown) == "function" then
    hooksecurefunc(mgr, "UpdateBarsShown", function() C_Timer.After(0, Silence) end)
  end
  M.statusWatch = w
end

function M:Init()
  ns.AfterCombat("blizzard", HideAll)
end

-- The raid frames load on demand.
ns.On("ADDON_LOADED", function(_, name)
  if name == "Blizzard_CompactRaidFrames" and ns.db and ns.db.hideBlizzard.raid and ns.db.modules.raid then
    ns.AfterCombat("blizzardRaid", function() Stash(CompactRaidFrameContainer) end)
  end
end)
