-- Plater, easier to read, in the ForeverXI look. Plater keeps doing all the
-- work (secret health, threat colours, casts, auras); ForeverXI only writes
-- some of its settings into your current Plater profile:
--   * Bigger text (names 12-13, health % and cast names 11), all with an
--     outline and a shadow, in Arial Narrow.
--   * Friendly players show just their name in class colour, no thin bar.
--     Friendly NPC names (name-only already) go from 9 to 12.
--   * Party and raid members keep a health bar (100x8, class colour), so
--     you can tell them apart from everyone else.
--   * Enemy bars a little bigger (120x14, 130x16 in combat) with health %.
--   * The XI look: flat fill, navy background, steel edge, XI cast colours
--     and the XI blue target highlight.
--
-- It writes them once, so anything you change in Plater afterwards sticks.
-- Every value it changes is saved first: /fxi plater undo puts them back,
-- /fxi plater writes the XI ones again.
local _, ns = ...

local M = ns.AddModule("PlaterSkin")

local STYLE = 2          -- bump when the look below changes (each step is written once)
local FLAT = "ForeverXI Flat"
local FONT = "Arial Narrow"

local function Navy(a) local c = ns.Style.colors.panelBottom return { c[1], c[2], c[3], a } end

local function RegisterMedia()
  local lsm = LibStub and LibStub("LibSharedMedia-3.0", true)
  if lsm then
    lsm:Register("statusbar", FLAT, "Interface\\Buttons\\WHITE8X8")
    lsm:Register("font", "ForeverXI", ns.Style.FONT)
  end
end

local function Copy(v)
  if type(v) ~= "table" then return v end
  local t = {}
  for k, x in pairs(v) do t[k] = Copy(x) end
  return t
end

-- Set p[...path] = value, saving the old value the first time.
local saved
local function Set(root, path, value)
  local t = root
  for i = 1, #path - 1 do
    t = t[path[i]]
    if type(t) ~= "table" then return end
  end
  local key = path[#path]
  local id = table.concat(path, ".")
  if saved[id] == nil then saved[id] = { v = Copy(t[key]) } end
  t[key] = Copy(value)
end

local TEXTS = { "actorname", "big_actorname", "spellname", "spellpercent", "level", "percent" }
local SIZES = {
  enemynpc       = { actorname = 12, spellname = 11, spellpercent = 10, percent = 11 },
  enemyplayer    = { actorname = 12, spellname = 11, spellpercent = 10, percent = 11 },
  friendlynpc    = { actorname = 12, big_actorname = 12, spellname = 11 },
  friendlyplayer = { actorname = 13, big_actorname = 12, spellname = 11 },
}

local function Write(p)
  local function S(path, v) Set(p, path, v) end
  -- The XI look.
  S({ "health_statusbar_texture" }, FLAT)
  S({ "health_statusbar_bgtexture" }, FLAT)
  S({ "health_statusbar_bgcolor" }, Navy(0.92))
  S({ "health_selection_overlay" }, FLAT)
  S({ "health_selection_overlay_alpha" }, 0.08)
  S({ "cast_statusbar_texture" }, FLAT)
  S({ "cast_statusbar_bgtexture" }, FLAT)
  S({ "cast_statusbar_bgcolor" }, Navy(0.92))
  local cr, cg, cb = ns.Style.Color("cast")
  S({ "cast_statusbar_color" }, { cr, cg, cb, 1 })
  local lr, lg, lb = ns.Style.Color("castLocked")
  S({ "cast_statusbar_color_nointerrupt" }, { lr, lg, lb, 1 })
  local er, eg, eb = ns.Style.Color("edge")
  S({ "border_color" }, { er, eg, eb, 1 })
  S({ "border_thickness" }, 1)
  local hr, hg, hb = ns.Style.Color("edgeLight")
  S({ "target_highlight_color" }, { hr, hg, hb, 1 })

  for kind, sizes in pairs(SIZES) do
    local c = p.plate_config and p.plate_config[kind]
    if type(c) == "table" then
      for _, t in ipairs(TEXTS) do
        if c[t .. "_text_font"] ~= nil then S({ "plate_config", kind, t .. "_text_font" }, FONT) end
        if c[t .. "_text_outline"] ~= nil then S({ "plate_config", kind, t .. "_text_outline" }, "OUTLINE") end
        if c[t .. "_text_shadow_color"] ~= nil then S({ "plate_config", kind, t .. "_text_shadow_color" }, { 0, 0, 0, 1 }) end
        if sizes[t] and c[t .. "_text_size"] ~= nil then S({ "plate_config", kind, t .. "_text_size" }, sizes[t]) end
      end
    end
  end

  -- Friendly players: name only, in class colour.
  local fp = p.plate_config and p.plate_config.friendlyplayer
  if type(fp) == "table" then
    S({ "plate_config", "friendlyplayer", "only_thename" }, true)
    S({ "plate_config", "friendlyplayer", "only_damaged" }, false)
    if fp.actorname_use_class_color ~= nil then S({ "plate_config", "friendlyplayer", "actorname_use_class_color" }, true) end
  end

  -- Enemies: a bit bigger, with health %.
  for _, kind in ipairs({ "enemynpc", "enemyplayer" }) do
    local c = p.plate_config and p.plate_config[kind]
    if type(c) == "table" then
      if c.health then S({ "plate_config", kind, "health" }, { 120, 14 }) end
      if c.health_incombat then S({ "plate_config", kind, "health_incombat" }, { 130, 16 }) end
      if c.cast then S({ "plate_config", kind, "cast" }, { 120, 12 }) end
      if c.cast_incombat then S({ "plate_config", kind, "cast_incombat" }, { 130, 14 }) end
      if c.percent_text_enabled ~= nil then S({ "plate_config", kind, "percent_text_enabled" }, true) end
      if c.percent_text_color then S({ "plate_config", kind, "percent_text_color" }, { 1, 1, 1, 1 }) end
    end
  end
end

-- Step 2: party and raid members keep a health bar (everyone else stays
-- name only), so a thicker friendly bar that you can read.
local function Write2(p)
  local fp = p.plate_config and p.plate_config.friendlyplayer
  if type(fp) ~= "table" then return end
  if fp.health then Set(p, { "plate_config", "friendlyplayer", "health" }, { 100, 8 }) end
  if fp.health_incombat then Set(p, { "plate_config", "friendlyplayer", "health_incombat" }, { 100, 8 }) end
end

local function InGroup(unit)
  if not unit or ns.Bool(UnitIsUnit, unit, "player") then return false end
  return ns.Bool(UnitInParty, unit) or ns.Bool(UnitInRaid, unit) or false
end

-- Plater shows friendly players as names only (our step 1). Party and raid
-- members get their bar back. Plater re-checks this every tick per plate.
local wrapped
local function WrapPartyBars()
  if wrapped or type(Plater.ParseHealthSettingForPlayer) ~= "function" or type(Plater.ShowHealthBar) ~= "function" then return end
  wrapped = true
  local orig = Plater.ParseHealthSettingForPlayer
  Plater.ParseHealthSettingForPlayer = function(plateFrame, force, ...)
    local o = ns.db.plater
    local uf = plateFrame and plateFrame.unitFrame
    local unit = plateFrame and (plateFrame.namePlateUnitToken or (uf and uf.namePlateUnitToken))
    if o.skin and o.partyBars and uf and InGroup(unit) then
      if plateFrame.IsFriendlyPlayerWithoutHealthBar or force then pcall(Plater.ShowHealthBar, uf) end
      return
    end
    return orig(plateFrame, force, ...)
  end
end

local function Refresh()
  if Plater.RefreshDBUpvalues then pcall(Plater.RefreshDBUpvalues) end
  if Plater.UpdateAllPlates then pcall(Plater.UpdateAllPlates, true) end
  if Plater.FullRefreshAllPlates then pcall(Plater.FullRefreshAllPlates) end
end

local function Ready(loud)
  if type(Plater) ~= "table" or not (Plater.db and Plater.db.profile) then
    if loud then ns.Print("Plater isn't loaded.") end
    return false
  end
  return true
end

function M.Apply(force)
  if not Ready(force) then return false end
  RegisterMedia()
  if not force and (ns.db.plater.applied or 0) >= STYLE then return true end
  ns.db.plater.backup = ns.db.plater.backup or {}
  saved = ns.db.plater.backup
  local applied = force and 0 or (ns.db.plater.applied or 0)
  local ok, err = pcall(function()
    if applied < 1 then Write(Plater.db.profile) end
    if applied < 2 then Write2(Plater.db.profile) end
  end)
  if not ok then
    ns.Print("couldn't restyle Plater (%s).", tostring(err))
    return false
  end
  ns.db.plater.applied = STYLE
  WrapPartyBars()
  Refresh()
  ns.Print("Plater set up to be easier to read. Changes you make in Plater stay; /fxi plater undo puts your old settings back.")
  return true
end

function M.Undo()
  if not Ready(true) then return end
  local b = ns.db.plater.backup
  if not b or not next(b) then ns.Print("nothing to undo.") return end
  local p = Plater.db.profile
  for id, e in pairs(b) do
    local t, parts = p, {}
    for part in id:gmatch("[^%.]+") do parts[#parts + 1] = part end
    for i = 1, #parts - 1 do t = type(t) == "table" and t[parts[i]] or nil end
    if type(t) == "table" then t[parts[#parts]] = Copy(e.v) end
  end
  ns.db.plater.backup = nil
  ns.db.plater.applied = STYLE          -- don't re-apply on the next login
  ns.db.plater.skin = false
  Refresh()
  ns.Print("Plater is back to your old settings (and ForeverXI won't touch it again unless you /fxi plater).")
end

function M:Init()
  if not ns.db.plater.skin then return end
  -- Plater sets its profile up at login; wait a moment after that. Our flat
  -- texture has to be registered every login (Plater looks it up by name).
  C_Timer.After(2, function()
    if type(Plater) ~= "table" then return end
    RegisterMedia()
    WrapPartyBars()
    if (ns.db.plater.applied or 0) >= STYLE then Refresh() else M.Apply(false) end
  end)
end
