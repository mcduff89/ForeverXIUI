-- ForeverXI core: saved settings, events, the out-of-combat queue and the
-- module list. Everything else hangs off the shared namespace `ns`.
local ADDON, ns = ...

ns.name = ADDON
ns.version = "0.1.2"
ns.DB_VERSION = 1

-- Defaults. New keys are filled in on load, so adding one here is safe for
-- existing saved settings. Renaming or removing one needs a step in Migrate.
ns.defaults = {
  dbVersion = 1,
  scale = 1,
  -- Per-frame size on top of the global scale.
  frameScale = { player = 1, playerCast = 1, target = 1, targetCast = 1, party = 1, raid = 1 },
  compact = false,
  modules = {
    player = true,
    target = true,
    playerCast = true,
    targetCast = true,
    party = true,
    raid = true,
    chat = true,
  },
  hideBlizzard = {
    player = true,
    target = true,
    cast = true,
    party = true,
    raid = true,
  },
  party = {
    showSolo = true,     -- XIUI "show party list when solo"
  },
  raid = {
    hideOwnGroup = true, -- your own group is already in the party list
  },
  positions = {},        -- filled by the movers; empty means "use the default"
}

local function FillDefaults(dst, src)
  for k, v in pairs(src) do
    if type(v) == "table" then
      if type(dst[k]) ~= "table" then dst[k] = {} end
      FillDefaults(dst[k], v)
    elseif dst[k] == nil then
      dst[k] = v
    end
  end
end

-- One step per saved-settings version. Nothing to migrate yet (version 1).
local function Migrate(db)
  db.dbVersion = tonumber(db.dbVersion) or 1
  -- if db.dbVersion < 2 then ... db.dbVersion = 2 end
end

function ns.Print(msg, ...)
  if select("#", ...) > 0 then msg = msg:format(...) end
  DEFAULT_CHAT_FRAME:AddMessage("|cff78c4eeForeverXI|r " .. tostring(msg))
end

-- pcall that only reports success and the first result.
function ns.Try(fn, ...)
  local ok, a, b, c, d = pcall(fn, ...)
  if ok then return true, a, b, c, d end
  return false
end

-- True only for a value we are allowed to read. Use type(), never `== nil`
-- or `if v`, on anything that might be secret: those can throw on Forever.
function ns.Readable(v)
  if type(v) == "nil" then return false end
  if issecretvalue then
    local ok, secret = pcall(issecretvalue, v)
    if not ok or secret then return false end
  end
  return true
end

-- A plain true/false from a call that might return a secret boolean.
function ns.Bool(fn, ...)
  local ok, v = pcall(fn, ...)
  if not ok or not ns.Readable(v) then return nil end
  return v and true or false
end

---------------------------------------------------------------------------
-- Events
---------------------------------------------------------------------------
local driver = CreateFrame("Frame")
local handlers = {}

function ns.On(event, fn)
  if not handlers[event] then
    handlers[event] = {}
    driver:RegisterEvent(event)
  end
  table.insert(handlers[event], fn)
end

driver:SetScript("OnEvent", function(_, event, ...)
  local list = handlers[event]
  if not list then return end
  for i = 1, #list do
    local ok, err = pcall(list[i], event, ...)
    if not ok then
      geterrorhandler()(err)
    end
  end
end)

---------------------------------------------------------------------------
-- Out-of-combat queue: secure frames can't be shown, moved or rebuilt while
-- InCombatLockdown() is true, so those jobs wait for PLAYER_REGEN_ENABLED.
---------------------------------------------------------------------------
local queued, queueOrder = {}, {}

function ns.AfterCombat(key, fn)
  if not InCombatLockdown() then
    fn()
    return true
  end
  if not queued[key] then table.insert(queueOrder, key) end
  queued[key] = fn
  return false
end

ns.On("PLAYER_REGEN_ENABLED", function()
  local order = queueOrder
  queueOrder = {}
  for _, key in ipairs(order) do
    local fn = queued[key]
    queued[key] = nil
    if fn then
      local ok, err = pcall(fn)
      if not ok then geterrorhandler()(err) end
    end
  end
end)

---------------------------------------------------------------------------
-- Modules. Each file adds itself with ns.AddModule(name, table) and gets
-- :Init() at login, in file order.
---------------------------------------------------------------------------
ns.modules = {}
ns.moduleOrder = {}

function ns.AddModule(name, mod)
  mod = mod or {}
  mod.name = name
  ns.modules[name] = mod
  table.insert(ns.moduleOrder, name)
  return mod
end

function ns.ForEachModule(method, ...)
  for _, name in ipairs(ns.moduleOrder) do
    local mod = ns.modules[name]
    if mod[method] then
      local ok, err = pcall(mod[method], mod, ...)
      if not ok then geterrorhandler()(err) end
    end
  end
end

ns.On("ADDON_LOADED", function(_, name)
  if name ~= ADDON then return end
  ForeverXIDB = ForeverXIDB or {}
  Migrate(ForeverXIDB)
  FillDefaults(ForeverXIDB, ns.defaults)
  ForeverXIDB.dbVersion = ns.DB_VERSION
  ns.db = ForeverXIDB
end)

ns.On("PLAYER_LOGIN", function()
  ns.ForEachModule("Init")
  ns.ApplyScale()
  ns.Print("v%s loaded. /fxi for options, /fxi move to place frames.", ns.version)
end)

-- Scale for every module root. Secure roots can't be rescaled in combat.
ns.roots = {}
function ns.AddRoot(frame, key)
  frame.fxiKey = key
  table.insert(ns.roots, frame)
end

function ns.ApplyScale()
  ns.AfterCombat("scale", function()
    local s = tonumber(ns.db and ns.db.scale) or 1
    local per = ns.db and ns.db.frameScale or {}
    for _, f in ipairs(ns.roots) do
      local k = tonumber(f.fxiKey and per[f.fxiKey]) or 1
      f:SetScale(math.max(0.3, s * k))
    end
    if ns.Movers then ns.Movers.ApplyAll() end
  end)
end
