-- /fxi check: what this Forever client lets addons read right now. Run it
-- out of combat, then again in combat with a mob targeted, and send the
-- output. It only reads; nothing is changed.
local _, ns = ...

local function Say(label, value)
  print(("  %s: |cffffffff%s|r"):format(label, value))
end

local function Describe(fn, ...)
  local ok, v = pcall(fn, ...)
  if not ok then return "error" end
  if type(v) == "nil" then return "nil" end
  if issecretvalue and issecretvalue(v) then return type(v) .. " (secret)" end
  return tostring(v)
end

function ns.Check()
  ns.Print("check (%s):", InCombatLockdown() and "IN combat" or "out of combat")
  local _, build, _, iface = GetBuildInfo()
  Say("build / interface", tostring(build) .. " / " .. tostring(iface))
  Say("issecretvalue exists", tostring(issecretvalue ~= nil))
  Say("C_Secrets exists", tostring(C_Secrets ~= nil))
  if C_Secrets and C_Secrets.ShouldAurasBeSecret then
    Say("auras secret now", Describe(C_Secrets.ShouldAurasBeSecret))
  end
  Say("C_CurveUtil exists", tostring(C_CurveUtil ~= nil))
  Say("UnitHealthPercent exists", tostring(UnitHealthPercent ~= nil))
  Say("percent curve built", tostring(ns.Values.PercentCurve() ~= nil))
  Say("player health", Describe(UnitHealth, "player"))
  Say("player max health", Describe(UnitHealthMax, "player"))
  Say("player mana", Describe(UnitPower, "player"))
  if UnitExists("target") then
    Say("target name", Describe(UnitName, "target"))
    Say("target health", Describe(UnitHealth, "target"))
    Say("target max health", Describe(UnitHealthMax, "target"))
    Say("target casting", Describe(UnitCastingInfo, "target"))
    if UnitThreatSituation then
      Say("your threat on target", Describe(UnitThreatSituation, "player", "target"))
    else
      Say("your threat on target", "UnitThreatSituation missing")
    end
  else
    Say("target", "none (target a mob and run again)")
  end
  -- Party buffs/debuffs: the game's aura containers, drawn by the game.
  Say("aura containers available", tostring(ns.Auras and ns.Auras.Available() or false))
  if ns.Auras then
    local st = ns.Auras.stats
    Say("party aura rows built / failed", st.built .. " / " .. st.failed)
    if st.lastError then Say("aura error", st.lastError) end
  end
  if C_RestrictedActions and C_RestrictedActions.IsAddOnRestrictionActive and Enum and Enum.AddOnRestrictionType then
    local id = Enum.AddOnRestrictionType.Combat
    if id then Say("combat restriction active", Describe(C_RestrictedActions.IsAddOnRestrictionActive, id)) end
  end
  if UnitExists("target") then
    local tb = ns.modules.TargetBar
    if tb and tb.MobInfo then Say("mob info", (tb.MobInfo("target"))) end
    Say("target of target", Describe(UnitName, "targettarget"))
  end
  Say("pet", Describe(UnitName, "pet"))
  Say("your XP", Describe(UnitXP, "player") .. " / " .. Describe(UnitXPMax, "player"))
  local mapSkin = ns.modules.MapSkin
  if mapSkin and mapSkin.DamageMeterNames then Say("damage meter frames", mapSkin.DamageMeterNames()) end
  if mapSkin and mapSkin.ButtonCount then Say("minimap buttons", mapSkin.ButtonCount()) end
  Say("GetMinimapShape", GetMinimapShape and tostring(GetMinimapShape()) or "nil")
  local swing = ns.modules.SwingTimer
  if swing and swing.Source then Say("swing timer source", swing.Source()) end
  local ok, have = pcall(GetTotemInfo, 1)
  Say("totem slot 1", ok and (ns.Readable(have) and tostring(have) or "secret") or "GetTotemInfo missing")
  Say("money", Describe(GetMoney))
  local bars = ns.modules.ActionBars
  if bars and bars.Names then Say("action bars", bars:Names()) end
  Say("Settings API", tostring(Settings ~= nil and Settings.RegisterAddOnSetting ~= nil))
  Say("Edit Mode callbacks", tostring(EventRegistry ~= nil))
end
