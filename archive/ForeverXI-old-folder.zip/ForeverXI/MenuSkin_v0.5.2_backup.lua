-- The XI menu: Blizzard's micro menu faded out and replaced by a navy window
-- of plain text entries (Character, Spells, Quests, Bags, ...), FFXI style.
--
-- How it opens things without tainting Forever: each entry is a secure
-- button that hands its click to Blizzard's own (now invisible) button
-- ("type" = "click", "clickbutton" = that button), so the game opens the
-- window in its own secure path. Calling ToggleCharacter() and friends from
-- addon code taints the panel manager on Forever, so nothing here does.
-- The game menu can't be opened even that way (Blizzard blocks addons and
-- its button only reacts "if self:IsMouseOver()"), so Blizzard's real menu
-- button sits invisibly over our "Menu" entry and takes the click itself.
--
-- The bag bar: faded and taken off the mouse (B and your bag keys still work).
local _, ns = ...

local M = ns.AddModule("MenuSkin")

-- label, Blizzard button(s) to hand the click to (first that exists).
local ENTRIES = {
  { "Character", { "CharacterMicroButton" } },
  { "Spells", { "SpellbookMicroButton", "PlayerSpellsMicroButton" } },
  { "Talents", { "TalentMicroButton" } },
  { "Professions", { "ProfessionMicroButton" } },
  { "Quests", { "QuestLogMicroButton" } },
  { "Map", { "@zone" } },
  { "Guild", { "GuildMicroButton" } },
  { "Group", { "LFDMicroButton", "LFGMicroButton" } },
  { "Legacy", { "LegacyMicroButton" } },
  { "Bags", { "MainMenuBarBackpackButton" } },
  { "Menu", { "MainMenuMicroButton" }, overlay = true },
}

local MICRO_CONTAINERS = { "MicroMenuContainer", "MicroMenu", "MicroButtonAndBagsBar" }
local ENTRY_H, ENTRY_PAD, WIN_PAD = 18, 8, 4

---------------------------------------------------------------------------
-- Fading Blizzard's bars (Edit Mode frames: faded, never hidden or moved).
---------------------------------------------------------------------------
local held = {}
local function KeepFaded(frame)
  if held[frame] and frame:GetAlpha() > 0 then frame:SetAlpha(0) end
end

local function Fade(frame)
  if type(frame) ~= "table" or not frame.SetAlpha then return end
  frame:SetAlpha(0)
  if not held[frame] then
    held[frame] = true
    hooksecurefunc(frame, "SetAlpha", KeepFaded)
  end
end

local BAG_BUTTONS = { "MainMenuBarBackpackButton", "CharacterBag0Slot", "CharacterBag1Slot",
  "CharacterBag2Slot", "CharacterBag3Slot", "CharacterReagentBag0Slot", "BagBarExpandToggle" }

local function HideBagBar()
  if type(BagsBar) ~= "table" then return end
  Fade(BagsBar)
  for _, name in ipairs(BAG_BUTTONS) do
    local b = _G[name]
    if type(b) == "table" and b.EnableMouse then pcall(b.EnableMouse, b, false) end
  end
end

-- Micro buttons: faded with their bar and off the mouse, so the invisible
-- buttons don't catch clicks. Our entries click them with :Click(), which
-- doesn't need the mouse.
local function HideMicroMenu(keep)
  for _, name in ipairs(MICRO_CONTAINERS) do
    local c = _G[name]
    if type(c) == "table" and c.GetChildren then
      Fade(c)
      for _, child in ipairs({ c:GetChildren() }) do
        if child ~= keep and child.EnableMouse then pcall(child.EnableMouse, child, false) end
      end
    end
  end
end

---------------------------------------------------------------------------
-- The menu
---------------------------------------------------------------------------
local function Target(names)
  for _, n in ipairs(names) do
    if n == "@zone" then
      local zone = MinimapCluster and rawget(MinimapCluster, "ZoneTextButton") or _G.MinimapZoneTextButton
      if type(zone) == "table" and zone.Click then return zone end
    else
      local b = _G[n]
      if type(b) == "table" and b.Click then return b end
    end
  end
end

local function Paint(e, hover)
  if hover then
    e.text:SetTextColor(ns.Style.Color("edgeLight"))
    e.hl:Show()
  else
    e.text:SetTextColor(1, 1, 1)
    e.hl:Hide()
  end
end

local function BuildEntry(win, label, target, overlay)
  local e = CreateFrame("Button", nil, win, "SecureActionButtonTemplate")
  e:SetHeight(ENTRY_H)
  e:RegisterForClicks("AnyUp", "AnyDown")
  e.text = ns.Style.Text(e, 12)
  e.text:SetPoint("CENTER")
  e.text:SetText(label)
  e:SetWidth(math.ceil((e.text:GetStringWidth() or 40) + ENTRY_PAD * 2))
  e.hl = e:CreateTexture(nil, "BACKGROUND")
  e.hl:SetAllPoints()
  e.hl:SetColorTexture(0.47, 0.77, 0.93, 0.14)
  e.hl:Hide()
  e:SetScript("OnEnter", function(self) Paint(self, true) end)
  e:SetScript("OnLeave", function(self) Paint(self, false) end)

  if overlay then
    -- Blizzard's own button, invisible, on top of the entry.
    target:SetParent(e)
    target:ClearAllPoints()
    target:SetAllPoints(e)
    target:SetFrameLevel(e:GetFrameLevel() + 10)
    if target.EnableMouse then target:EnableMouse(true) end
    target:SetAlpha(0)
    held[target] = true
    hooksecurefunc(target, "SetAlpha", KeepFaded)
    local placing = false
    hooksecurefunc(target, "SetPoint", function()
      if placing then return end
      ns.AfterCombat("menuOverlay", function()
        placing = true
        target:ClearAllPoints()
        target:SetAllPoints(e)
        placing = false
      end)
    end)
    target:HookScript("OnEnter", function() Paint(e, true) end)
    target:HookScript("OnLeave", function() Paint(e, false) end)
  else
    e:SetAttribute("type", "click")
    e:SetAttribute("clickbutton", target)
    e:SetAttribute("useOnKeyDown", false)
  end
  return e
end

local function Arrange(win, entries)
  local vertical = ns.db.menu.vertical
  local x, y, w = WIN_PAD, -WIN_PAD, 0
  for _, e in ipairs(entries) do
    e:ClearAllPoints()
    e:SetPoint("TOPLEFT", win, "TOPLEFT", x, y)
    if vertical then
      y = y - ENTRY_H
      w = math.max(w, e:GetWidth())
    else
      x = x + e:GetWidth()
    end
  end
  if vertical then
    for _, e in ipairs(entries) do e:SetWidth(w) end
    win:SetSize(w + WIN_PAD * 2, -y + WIN_PAD)
  else
    win:SetSize(x + WIN_PAD, ENTRY_H + WIN_PAD * 2)
  end
end

function M:Init()
  if ns.db.hideBagBar then ns.AfterCombat("hideBagBar", HideBagBar) end
  if not ns.db.menuSkin then return end
  ns.AfterCombat("xiMenu", function()
    local win = CreateFrame("Frame", "ForeverXIMenu", UIParent)
    win:SetFrameStrata("MEDIUM")
    ns.Style.Panel(win, 0.92)
    local entries, keep = {}, nil
    for _, spec in ipairs(ENTRIES) do
      local target = Target(spec[2])
      if target then
        local ok, e = pcall(BuildEntry, win, spec[1], target, spec.overlay)
        if ok and e then
          entries[#entries + 1] = e
          if spec.overlay then keep = target end
        end
      end
    end
    if #entries == 0 then
      win:Hide()
      ns.Print("couldn't find Blizzard's menu buttons; the XI menu is off.")
      return
    end
    Arrange(win, entries)
    HideMicroMenu(keep)
    self.frame, self.entries = win, entries
    ns.AddRoot(win, "menu")
    ns.Movers.Register("menu", "Menu", win, { "TOPLEFT", "TOPLEFT", 8, -4 })
    ns.ApplyScale()
  end)
end

function M:Relayout()
  if self.frame then
    ns.AfterCombat("xiMenuLayout", function() Arrange(self.frame, self.entries) end)
  end
end
