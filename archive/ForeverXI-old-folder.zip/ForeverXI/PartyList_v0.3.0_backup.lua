-- Party list (XIUI style): one navy window, a row per member with class
-- icon and name, HP bar with "1108 (100%)" and a power bar. You are the
-- bottom row. The window grows upward from its bottom edge, like XIUI's
-- "align bottom". In a raid it shows your own group.
--
-- Beside each row: that member's pet on one side, on the same line as its
-- owner, and their buffs (name line) and debuffs (bar line), drawn by the
-- game (Auras.lua), on the other. Pets left and icons right by default;
-- "Flip sides" swaps them.
--
-- Rows are secure unit buttons: left-click targets, right-click opens the
-- unit menu. Their order is rebuilt out of combat; a roster change during
-- combat is laid out when combat ends.
local _, ns = ...

local M = ns.AddModule("PartyList")

local W, W_COMPACT = 236, 190
local ROW_H, PAD, TITLE_H = 30, 6, 14
local UNITS = { "player", "party1", "party2", "party3", "party4" }
local PETS = { "pet", "partypet1", "partypet2", "partypet3", "partypet4" }
local PET_W, PET_GAP = 118, 4
local AURA_GAP = PAD + 3   -- from the row's left edge to clear the window edge
local UNIT_EVENTS = { "UNIT_HEALTH", "UNIT_MAXHEALTH", "UNIT_POWER_UPDATE", "UNIT_MAXPOWER",
  "UNIT_DISPLAYPOWER", "UNIT_NAME_UPDATE", "UNIT_CONNECTION", "UNIT_FLAGS" }

local rows, pets = {}, {}

local function Width() return ns.db.compact and W_COMPACT or W end

local function UpdateRow(row)
  local unit = row.unit
  if not UnitExists(unit) then return end
  ns.Values.Name(row.name, unit)
  local _, class = UnitClass(unit)
  ns.Style.ClassIcon(row.icon, class)

  if ns.Values.IsOffline(unit) then
    row.name:SetTextColor(0.55, 0.55, 0.55)
    row.hp:SetMinMaxValues(0, 1)
    row.hp:SetValue(0)
    row.hpText:SetText("Offline")
    row.mp:SetValue(0)
    row.mpText:SetText("")
    return
  end
  row.name:SetTextColor(1, 1, 1)
  ns.Values.Health(row.hp, row.hpText, unit, "both", true)
  ns.Values.Power(row.mp, row.mpText, unit, "value")
  if ns.Values.IsDead(unit) then row.hpText:SetText("Dead") end
end

-- The look of a row, shared by the real (secure) rows and the preview rows.
local function BuildParts(row)
  row.icon = row:CreateTexture(nil, "ARTWORK")
  row.icon:SetSize(13, 13)
  row.icon:SetPoint("TOPLEFT", row, "TOPLEFT", 2, -1)
  row.name = ns.Style.Text(row, 11)
  row.name:SetPoint("LEFT", row.icon, "RIGHT", 4, 0)
  row.name:SetJustifyH("LEFT")
  row.name:SetWordWrap(false)

  row.hp = ns.Style.Bar(row, 140, 10, "hpHigh")
  row.hp:SetPoint("BOTTOMLEFT", row, "BOTTOMLEFT", 2, 3)
  row.hpText = ns.Style.BarText(row.hp, 10)

  row.mp = ns.Style.Bar(row, 76, 10, "mana")
  row.mp:SetPoint("LEFT", row.hp, "RIGHT", 6, 0)
  row.mp:SetPoint("RIGHT", row, "RIGHT", -2, 0)
  row.mpText = ns.Style.BarText(row.mp, 10)
end

local function BuildRow(parent, unit, index)
  local row = CreateFrame("Button", "ForeverXIParty" .. index, parent, "SecureUnitButtonTemplate")
  row.unit = unit
  row:SetAttribute("unit", unit)
  row:SetAttribute("*type1", "target")
  row:SetAttribute("*type2", "togglemenu")
  row:RegisterForClicks("AnyUp")

  local hl = row:CreateTexture(nil, "HIGHLIGHT")
  hl:SetAllPoints()
  hl:SetColorTexture(0.47, 0.77, 0.93, 0.12)

  BuildParts(row)

  for _, e in ipairs(UNIT_EVENTS) do pcall(row.RegisterUnitEvent, row, e, unit) end
  row:SetScript("OnEvent", UpdateRow)
  row:HookScript("OnShow", UpdateRow)
  return row
end

---------------------------------------------------------------------------
-- Pets: a small window right of the owner's row, same line.
---------------------------------------------------------------------------
local function UpdatePet(pet)
  local unit = pet.unit
  if not UnitExists(unit) then return end
  ns.Values.Name(pet.name, unit)
  ns.Values.Health(pet.hp, pet.hpText, unit, "percent", true)
  if ns.Values.IsDead(unit) then pet.hpText:SetText("Dead") end
end

local function BuildPetParts(pet)
  local back = CreateFrame("Frame", nil, pet)
  back:SetAllPoints()
  back:SetFrameLevel(math.max(0, pet:GetFrameLevel() - 1))
  ns.Style.Panel(back, nil, 0)
  pet.back = back
  pet.name = ns.Style.Text(pet, 10)
  pet.name:SetPoint("TOPLEFT", pet, "TOPLEFT", 5, -3)
  pet.name:SetPoint("TOPRIGHT", pet, "TOPRIGHT", -5, -3)
  pet.name:SetJustifyH("LEFT")
  pet.name:SetWordWrap(false)
  pet.name:SetTextColor(ns.Style.Color("title"))
  pet.hp = ns.Style.Bar(pet, PET_W - 10, 8, "hpHigh")
  pet.hp:SetPoint("BOTTOMLEFT", pet, "BOTTOMLEFT", 5, 5)
  pet.hpText = ns.Style.BarText(pet.hp, 9)
end

local function BuildPet(parent, row, index)
  local pet = CreateFrame("Button", "ForeverXIPartyPet" .. index, parent, "SecureUnitButtonTemplate")
  pet.unit = PETS[index]
  pet:SetAttribute("unit", pet.unit)
  pet:SetAttribute("*type1", "target")
  pet:SetAttribute("*type2", "togglemenu")
  pet:RegisterForClicks("AnyUp")
  pet:SetSize(PET_W, ROW_H)
  pet.owner = row
  local hl = pet:CreateTexture(nil, "HIGHLIGHT")
  hl:SetAllPoints()
  hl:SetColorTexture(0.47, 0.77, 0.93, 0.12)
  BuildPetParts(pet)
  for _, e in ipairs({ "UNIT_HEALTH", "UNIT_MAXHEALTH", "UNIT_NAME_UPDATE", "UNIT_FLAGS" }) do
    pcall(pet.RegisterUnitEvent, pet, e, pet.unit)
  end
  pcall(pet.RegisterUnitEvent, pet, "UNIT_PET", row.unit)
  pet:SetScript("OnEvent", UpdatePet)
  pet:HookScript("OnShow", UpdatePet)
  RegisterUnitWatch(pet)
  return pet
end

-- Pets go on the side the icons don't use. Secure: out of combat only.
local function PlacePet(pet, owner)
  pet:ClearAllPoints()
  if ns.db.party.flip then
    pet:SetPoint("TOPLEFT", owner, "TOPRIGHT", PAD + PET_GAP, 0)
  else
    pet:SetPoint("TOPRIGHT", owner, "TOPLEFT", -(PAD + PET_GAP), 0)
  end
end

local function Count()
  if not IsInGroup() then
    return ns.db.party.showSolo and 1 or 0
  end
  return 1 + (GetNumSubgroupMembers() or 0)
end

local function Title()
  if IsInRaid() then
    local idx = UnitInRaid("player")
    local group = idx and select(3, GetRaidRosterInfo(idx))
    return group and ("Group " .. group) or "Raid"
  end
  return IsInGroup() and "Party" or "Solo"
end

-- Panel size and title. Not secure, so this also runs in combat.
local function UpdatePanel(f)
  local n = Count()
  f.panelFrame:SetShown(n > 0)
  f.panelFrame:SetHeight(math.max(1, n) * ROW_H + PAD * 2)
  f.title:SetText(Title())
end

-- Row order and sizes. Secure: out of combat only.
local function LayoutRows(f)
  local w = Width()
  f:SetSize(w, #UNITS * ROW_H + PAD * 2 + TITLE_H)
  f.panelFrame:SetWidth(w)
  local n = Count()
  local shown = 0
  for i, row in ipairs(rows) do
    row:SetSize(w - PAD * 2, ROW_H)
    row.hp:SetWidth((w - PAD * 2) * 0.62)
    row:ClearAllPoints()
    if i == 1 or UnitExists(row.unit) then
      shown = shown + 1
      -- You at the bottom, members stack upward; the bottom edge stays put.
      local y = PAD + (shown - 1) * ROW_H
      row:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", PAD, y)
    else
      row:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", PAD, PAD)
    end
  end
end

local function Refresh(f)
  UpdatePanel(f)
  ns.AfterCombat("partyPets", function()
    for _, pet in pairs(pets) do PlacePet(pet, pet.owner) end
  end)
  ns.AfterCombat("partyLayout", function() LayoutRows(f) end)
  for _, row in ipairs(rows) do
    if row:IsShown() then UpdateRow(row) end
    if ns.Auras then ns.Auras.Refresh(row) end
  end
  for _, pet in pairs(pets) do
    if pet:IsShown() then UpdatePet(pet) end
  end
end

function M:Init()
  if not ns.db.modules.party then return end
  local f = CreateFrame("Frame", "ForeverXIPartyList", UIParent)
  f:SetSize(W, #UNITS * ROW_H + PAD * 2 + TITLE_H)

  -- The window behind the rows: a plain child frame, so its height can
  -- change in combat even though the rows are secure.
  local panel = CreateFrame("Frame", nil, f)
  panel:SetFrameLevel(math.max(0, f:GetFrameLevel() - 1))
  panel:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 0, 0)
  panel:SetSize(W, ROW_H + PAD * 2)
  ns.Style.Panel(panel)
  f.panelFrame = panel
  f.title = ns.Style.Text(panel, 11)
  f.title:SetPoint("BOTTOMRIGHT", panel, "TOPRIGHT", -4, 1)
  f.title:SetTextColor(ns.Style.Color("title"))

  for i, unit in ipairs(UNITS) do
    local row = BuildRow(f, unit, i)
    rows[i] = row
    if unit == "player" then
      if ns.db.party.showSolo then
        row:Show()
      else
        RegisterStateDriver(row, "visibility", "[group] show; hide")
      end
    else
      RegisterUnitWatch(row)
    end
    if ns.db.party.auras and ns.Auras then ns.Auras.Attach(row, unit, row, AURA_GAP) end
    if ns.db.party.pets then pets[i] = BuildPet(f, row, i) end
  end

  f:RegisterEvent("GROUP_ROSTER_UPDATE")
  f:RegisterEvent("PLAYER_ENTERING_WORLD")
  f:SetScript("OnEvent", Refresh)
  Refresh(f)

  self.frame = f
  ns.AddRoot(f, "party")
  ns.Movers.Register("party", "Party list", f, { "BOTTOM", "BOTTOM", 0, 128 })
end

function M:Relayout()
  if self.frame and not self.previewing then
    Refresh(self.frame)
    if ns.Auras then
      for _, row in ipairs(rows) do ns.Auras.Apply(row) end
    end
  end
end

---------------------------------------------------------------------------
-- Preview: a pretend full party drawn over the real rows, for placing and
-- sizing the list. Plain frames only; the real rows are just faded.
---------------------------------------------------------------------------
local FAKE = {
  { "Duffnar", "SHAMAN", 100, "MANA", 47 },
  { "Yehva", "PALADIN", 88, "MANA", 12 },
  { "Jooppi", "WARLOCK", 61, "MANA", 80, "Voidwalker", 90 },
  { "Harlecin", "HUNTER", 38, "MANA", 55, "Broken Tooth", 72 },
  { "Mortium", "WARRIOR", 19, "RAGE", 30 },
}
local fakes, fakePets = {}, {}

function M:Preview(on)
  local f = self.frame
  if not f then return end
  self.previewing = on and true or nil
  local w = Width()
  for i, data in ipairs(FAKE) do
    local fake = fakes[i]
    if not fake then
      fake = CreateFrame("Frame", nil, f)
      fake:SetFrameLevel(f:GetFrameLevel() + 5)
      BuildParts(fake)
      fakes[i] = fake
    end
    if on then
      fake:SetSize(w - PAD * 2, ROW_H)
      fake.hp:SetWidth((w - PAD * 2) * 0.62)
      fake:ClearAllPoints()
      fake:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", PAD, PAD + (i - 1) * ROW_H)
      fake.name:SetText(data[1])
      ns.Style.ClassIcon(fake.icon, data[2])
      local maxHp = 1100
      local hp = math.floor(maxHp * data[3] / 100)
      fake.hp:SetMinMaxValues(0, maxHp)
      fake.hp:SetValue(hp)
      fake.hpText:SetFormattedText("%d (%d%%)", hp, data[3])
      if ns.db.look and ns.db.look.hpBands then
        local key = data[3] <= 25 and "hpLow" or data[3] <= 50 and "hpMedLow" or data[3] <= 75 and "hpMedHigh" or "hpHigh"
        fake.hp:SetStatusBarColor(ns.Style.Color(key))
      else
        fake.hp:SetStatusBarColor(ns.Style.Color(ns.Style.HealthKey("hpHigh")))
      end
      fake.mp:SetMinMaxValues(0, 100)
      fake.mp:SetValue(data[5])
      fake.mp:SetStatusBarColor(ns.Style.PowerRGB(data[4]))
      fake.mpText:SetText(data[4] == "RAGE" and data[5] or data[5] * 7)
      fake:Show()
    else
      fake:Hide()
    end
    if ns.Auras then ns.Auras.Preview(fake, on, fake, AURA_GAP, i) end

    -- Pretend pet on the owner's line.
    local fp = fakePets[i]
    if on and data[6] and ns.db.party.pets then
      if not fp then
        fp = CreateFrame("Frame", nil, f)
        fp:SetFrameLevel(f:GetFrameLevel() + 5)
        fp:SetSize(PET_W, ROW_H)
        BuildPetParts(fp)
        fakePets[i] = fp
      end
      PlacePet(fp, fake)
      fp.name:SetText(data[6])
      fp.hp:SetMinMaxValues(0, 100)
      fp.hp:SetValue(data[7])
      fp.hp:SetStatusBarColor(ns.Style.Color(ns.Style.HealthKey("hpHigh")))
      fp.hpText:SetFormattedText("%d%%", data[7])
      fp:Show()
    elseif fp then
      fp:Hide()
    end
  end
  for _, row in ipairs(rows) do row:SetAlpha(on and 0 or 1) end
  for _, pet in pairs(pets) do pet:SetAlpha(on and 0 or 1) end
  if on then
    f.panelFrame:Show()
    f.panelFrame:SetWidth(w)
    f.panelFrame:SetHeight(#FAKE * ROW_H + PAD * 2)
    f.title:SetText("Party (preview)")
  else
    Refresh(f)
  end
end
