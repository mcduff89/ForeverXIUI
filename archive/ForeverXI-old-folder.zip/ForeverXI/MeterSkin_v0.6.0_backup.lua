-- Damage meter skin: the game's built-in damage meter in an XI window.
-- Only looks: a navy panel with the steel edge behind each meter window,
-- and Blizzard's own background art faded. The meter is an Edit Mode frame,
-- so it is never moved, re-parented or hidden; place it in Edit Mode and
-- the window follows.
--
-- Blizzard hasn't documented the meter's frame names for addons, so this
-- looks in a few places (the global name, Edit Mode's registered system)
-- and skins every window it finds. /fxi check says what it found.
local _, ns = ...

local M = ns.AddModule("MeterSkin")

local NAMES = { "DamageMeter", "DamageMeterFrame" }
local DECOR = { "NineSlice", "Background", "Bg", "BackgroundTexture", "Backdrop", "Border" }

local faded, skinned, found = {}, {}, {}

local function KeepFaded(region)
  if faded[region] and region:GetAlpha() > 0 then region:SetAlpha(0) end
end

local function Fade(region)
  if type(region) ~= "table" or not region.SetAlpha or region.fxiOurs then return end
  region:SetAlpha(0)
  if not faded[region] then
    faded[region] = true
    hooksecurefunc(region, "SetAlpha", KeepFaded)
  end
end

local function Kind(f)
  local ok, k = pcall(f.GetObjectType, f)
  return ok and k or nil
end

-- One meter window: fade its decoration, put our panel just under it.
local function Skin(win)
  if skinned[win] or type(win) ~= "table" or not win.GetFrameLevel then return end
  local w = win.GetWidth and win:GetWidth() or 0
  if w < 60 then return end          -- buttons and bits, not a window
  skinned[win] = true
  for _, key in ipairs(DECOR) do
    local r = rawget(win, key)
    if type(r) == "table" and (Kind(r) == "Texture" or key == "NineSlice") then Fade(r) end
  end
  local back = CreateFrame("Frame", nil, win)
  back.fxiOurs = true
  back:SetFrameLevel(math.max(0, win:GetFrameLevel() - 1))
  back:SetPoint("TOPLEFT", win, "TOPLEFT", -2, 2)
  back:SetPoint("BOTTOMRIGHT", win, "BOTTOMRIGHT", 2, -2)
  ns.Style.Panel(back, 0.9)
  found[#found + 1] = win:GetName() or "window"
end

local function Roots()
  local out = {}
  for _, n in ipairs(NAMES) do
    if type(_G[n]) == "table" then out[#out + 1] = _G[n] end
  end
  if EditModeManagerFrame and EditModeManagerFrame.GetRegisteredSystemFrame
    and Enum and Enum.EditModeSystem and Enum.EditModeSystem.DamageMeter then
    local ok, f = pcall(EditModeManagerFrame.GetRegisteredSystemFrame, EditModeManagerFrame,
      Enum.EditModeSystem.DamageMeter)
    if ok and type(f) == "table" then out[#out + 1] = f end
  end
  return out
end

function M.Apply()
  if not ns.db.meter.skin then return end
  for _, root in ipairs(Roots()) do
    -- The meter's windows are its children (one per session window);
    -- if it has none that look like windows, skin the meter itself.
    local before = #found
    if root.GetChildren then
      for _, child in ipairs({ root:GetChildren() }) do
        if not child.fxiOurs and Kind(child) == "Frame" and (child:GetHeight() or 0) > 40 then Skin(child) end
      end
    end
    if #found == before then Skin(root) end
  end
end

function M:Init()
  if not ns.db.meter.skin then return end
  M.Apply()
  -- The meter loads on demand; skin it when it does, and when new windows open.
  ns.On("ADDON_LOADED", function(_, name)
    if type(name) == "string" and name:find("DamageMeter") then C_Timer.After(0.2, M.Apply) end
  end)
  ns.On("PLAYER_ENTERING_WORLD", function() C_Timer.After(2, M.Apply) end)
  ns.On("PLAYER_REGEN_DISABLED", M.Apply)
end

function M.Describe()
  local roots = {}
  for _, r in ipairs(Roots()) do roots[#roots + 1] = (r.GetName and r:GetName()) or "unnamed" end
  if #roots == 0 then return "none found (open the meter once, then check again)" end
  return ("%s; skinned %d: %s"):format(table.concat(roots, " "), #found,
    #found > 0 and table.concat(found, " ") or "-")
end
