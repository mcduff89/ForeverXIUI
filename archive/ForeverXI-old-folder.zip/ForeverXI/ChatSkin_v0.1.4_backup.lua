-- Chat windows in the FFXI/XIUI look: Blizzard's chat art removed, a navy
-- gradient window with a steel edge behind each chat frame, and the
-- window's name in the top-right corner like XI's "Window1". Only the look
-- changes; Blizzard's chat (and Prat, if you keep it) still does the work.
local _, ns = ...

local M = ns.AddModule("ChatSkin")

local ART = { "Background", "TopTexture", "BottomTexture", "LeftTexture", "RightTexture",
  "TopLeftTexture", "TopRightTexture", "BottomLeftTexture", "BottomRightTexture" }

local held = {}
local function KeepHidden(tex)
  if held[tex] and tex:GetAlpha() > 0 then tex:SetAlpha(0) end
end

local function HideArt(tex)
  if type(tex) ~= "table" or not tex.IsObjectType or not tex:IsObjectType("Texture") then return end
  tex:SetAlpha(0)
  if not held[tex] then
    held[tex] = true
    hooksecurefunc(tex, "SetAlpha", KeepHidden)
  end
end

local function Piece(cf, name, suffix)
  local t = name and _G[name .. suffix]
  if type(t) ~= "table" then t = cf[suffix] end
  return t
end

local skinned = {}

local function Skin(cf, id)
  if not cf or skinned[cf] then return end
  skinned[cf] = true
  local name = cf:GetName()
  for _, suffix in ipairs(ART) do HideArt(Piece(cf, name, suffix)) end

  local shell = CreateFrame("Frame", nil, cf)
  shell:SetFrameLevel(math.max(0, cf:GetFrameLevel() - 1))
  shell:SetPoint("TOPLEFT", cf, "TOPLEFT", -6, 6)
  shell:SetPoint("BOTTOMRIGHT", cf, "BOTTOMRIGHT", 6, -6)
  ns.Style.Panel(shell, 0.82)

  local label = ns.Style.Text(shell, 10)
  label:SetPoint("TOPRIGHT", shell, "TOPRIGHT", -5, -3)
  label:SetTextColor(ns.Style.Color("title"))
  label:SetAlpha(0.8)
  shell.label = label
  cf.fxiShell = shell

  local function Rename()
    local title = FCF_GetChatWindowInfo and FCF_GetChatWindowInfo(id)
    label:SetText(title or "")
  end
  Rename()
  shell.Rename = Rename
end

local function SkinAll()
  for i = 1, (NUM_CHAT_WINDOWS or 10) do
    Skin(_G["ChatFrame" .. i], i)
  end
end

function M:Init()
  if not ns.db.modules.chat then return end
  SkinAll()
  -- Renamed or newly opened windows.
  if type(FCF_SetWindowName) == "function" then
    hooksecurefunc("FCF_SetWindowName", function(frame)
      if frame and frame.fxiShell then frame.fxiShell.Rename() end
    end)
  end
  if type(FCF_OpenTemporaryWindow) == "function" then
    hooksecurefunc("FCF_OpenTemporaryWindow", function()
      for _, cf in ipairs(CHAT_FRAMES or {}) do
        local f = _G[cf]
        if f and not skinned[f] then Skin(f, f:GetID()) end
      end
    end)
  end
end
