-- Bag dots: XIUI's inventory tracker. One dot per bag slot, yellow when
-- something is in it and dark when it's free, with "used/total" above.
-- Only plain bags count (not ammo, soul or profession bags). It only reads
-- your bags; Baganator (or any bag addon) still does the sorting.
local _, ns = ...

local M = ns.AddModule("BagDots")

local DOT, GAP, PAD, TEXT_H = 7, 2, 5, 14
local FULL = { 1.00, 0.88, 0.10 }
local EMPTY = { 0.06, 0.14, 0.26 }

local function o() return ns.db.bagDots end

-- Each slot of the plain bags: true when something is in it.
local function Slots()
  local C = C_Container
  local numSlots = (C and C.GetContainerNumSlots) or GetContainerNumSlots
  local numFree = (C and C.GetContainerNumFreeSlots) or GetContainerNumFreeSlots
  local getInfo = C and C.GetContainerItemInfo
  local getID = (C and C.GetContainerItemID) or GetContainerItemID
  local list = {}
  if not numSlots then return list end
  for bag = 0, (NUM_BAG_SLOTS or 4) do
    local okS, n = pcall(numSlots, bag)
    local bagType = 0
    if numFree then
      local okF, _, t = pcall(numFree, bag)
      if okF then bagType = t end
    end
    if okS and type(n) == "number" and n > 0 and (bagType == nil or bagType == 0) then
      for slot = 1, n do
        local used = false
        if getID then
          local ok, id = pcall(getID, bag, slot)
          used = ok and id ~= nil
        elseif getInfo then
          local ok, info = pcall(getInfo, bag, slot)
          used = ok and info ~= nil
        end
        list[#list + 1] = used
      end
    end
  end
  return list
end
M.Slots = Slots

local function Dot(f, i)
  local d = f.dots[i]
  if d then return d end
  d = f:CreateTexture(nil, "ARTWORK")
  d:SetSize(DOT, DOT)
  d:SetTexture("Interface\\Buttons\\WHITE8X8")
  -- Round dots without needing a file: the minimap's round mask.
  if d.SetMask then pcall(d.SetMask, d, "Interface\\CharacterFrame\\TempPortraitAlphaMask") end
  f.dots[i] = d
  return d
end

local function Update(f)
  local slots = Slots()
  local total = #slots
  local used = 0
  for _, u in ipairs(slots) do if u then used = used + 1 end end
  local cols = math.max(5, tonumber(o().columns) or 20)
  local rows = math.max(1, math.ceil(total / cols))
  local width = PAD * 2 + cols * DOT + (cols - 1) * GAP
  local height = PAD * 2 + TEXT_H + rows * DOT + (rows - 1) * GAP
  f:SetSize(width, height)

  for i = 1, math.max(total, #f.dots) do
    local d = Dot(f, i)
    if i <= total then
      local c = slots[i] and FULL or EMPTY
      d:SetVertexColor(c[1], c[2], c[3], 1)
      local col, row = (i - 1) % cols, math.floor((i - 1) / cols)
      d:ClearAllPoints()
      d:SetPoint("TOPLEFT", f, "TOPLEFT", PAD + col * (DOT + GAP), -(PAD + TEXT_H + row * (DOT + GAP)))
      d:Show()
    else
      d:Hide()
    end
  end

  local free = total - used
  f.count:SetText(("%d/%d"):format(used, total))
  if free <= 2 then f.count:SetTextColor(1, 0.25, 0.25)
  elseif free <= 5 then f.count:SetTextColor(1, 0.6, 0.15)
  else f.count:SetTextColor(1, 1, 1) end
end

function M:Init()
  if not ns.db.modules.bagDots then return end
  local f = CreateFrame("Frame", "ForeverXIBagDots", UIParent)
  f:SetFrameStrata("LOW")
  f.dots = {}
  ns.Style.Panel(f, 0.85)
  ns.Style.ShowPanel(f, o().window ~= false)
  f.count = ns.Style.Text(f, 12)
  f.count:SetPoint("TOPRIGHT", f, "TOPRIGHT", -PAD, -PAD + 1)
  f.count:SetJustifyH("RIGHT")

  local pending = false
  local function Queue()
    if pending then return end
    pending = true
    C_Timer.After(0.1, function() pending = false; pcall(Update, f) end)
  end
  for _, e in ipairs({ "BAG_UPDATE_DELAYED", "BAG_UPDATE", "PLAYER_ENTERING_WORLD", "BAG_CONTAINER_UPDATE" }) do
    pcall(f.RegisterEvent, f, e)
  end
  f:SetScript("OnEvent", Queue)
  pcall(Update, f)

  self.frame = f
  ns.AddRoot(f, "bagDots")
  ns.Movers.Register("bagDots", "Bag dots", f, { "BOTTOMRIGHT", "BOTTOMRIGHT", -10, 250 })
  ns.ApplyScale()
end

function M:Relayout()
  if not self.frame then return end
  ns.Style.ShowPanel(self.frame, o().window ~= false)
  pcall(Update, self.frame)
end

function M.Describe()
  if not M.frame then return "off" end
  local s = Slots()
  local used = 0
  for _, u in ipairs(s) do if u then used = used + 1 end end
  return ("%d/%d slots used"):format(used, #s)
end
