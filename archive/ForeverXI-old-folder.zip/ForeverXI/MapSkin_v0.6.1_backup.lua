-- The minimap in the XI look: a square map in a navy window with a steel
-- edge, Blizzard's round border art faded, an XI strip under the map with
-- the zone, your coordinates and the clock, and every button that sat
-- around the map (Blizzard's and the addons' LibDBIcon ones) lined up
-- along the map's left edge, squared off and all one size.
--
-- Only looks: the map's mask texture and the alpha of Blizzard's art. The
-- minimap cluster is an Edit Mode frame and is never moved or re-parented;
-- place it in Edit Mode and the window follows. A /reload is needed to go
-- back to the round map.
local _, ns = ...

local M = ns.AddModule("MapSkin")

-- Round decoration on the minimap, by name or by key on the cluster/map.
local ART_NAMES = { "MinimapBorder", "MinimapBorderTop", "MinimapCompassTexture", "MinimapBackdrop",
  "MinimapNorthTag" }
local ART_KEYS = { "BorderTop", "Border", "Background" }

local faded = {}
local function KeepFaded(region)
  if faded[region] and region:GetAlpha() > 0 then region:SetAlpha(0) end
end

local function Fade(region)
  if type(region) ~= "table" or not region.SetAlpha then return end
  region:SetAlpha(0)
  if not faded[region] then
    faded[region] = true
    hooksecurefunc(region, "SetAlpha", KeepFaded)
  end
end

-- Addons that put buttons around the map (LibDBIcon) ask this to know where
-- the edge is.
local function SquareShape() return "SQUARE" end

---------------------------------------------------------------------------
-- The buttons along the map's edge. Buttons are only re-anchored and
-- scaled (never re-parented), and dragging them is turned off so they stay
-- in line. When an addon puts its button back (LibDBIcon does on every
-- update), the edge takes it again. They run down the map's left edge (the
-- right edge if the map is against the left of the screen); any that don't
-- fit carry on in a row under the zone strip.
---------------------------------------------------------------------------
local SLOT, GAP = 22, 2
local edge, strip, buttons, placing = nil, nil, {}, false

-- Blizzard's round ring and dark circle behind minimap buttons.
local ROUND_FILES = { [136430] = true, [136467] = true, [136477] = true }
local function IsRoundArt(tex)
  local ok, file = pcall(tex.GetTexture, tex)
  if not ok or file == nil then return false end
  if type(file) == "number" then return ROUND_FILES[file] or false end
  file = tostring(file):lower()
  return file:find("trackingborder") or file:find("minimap%-background") or file:find("ui%-minimap%-background")
end

local function Square(b)
  for _, key in ipairs({ "border", "Border", "background", "Background" }) do
    local r = rawget(b, key)
    if type(r) == "table" and r.SetAlpha then Fade(r) end
  end
  for _, r in ipairs({ b:GetRegions() }) do
    local ok, k = pcall(r.GetObjectType, r)
    if ok and k == "Texture" and IsRoundArt(r) then Fade(r) end
  end
  -- A small square XI tile behind the icon.
  if not b.fxiTile then
    local t = b:CreateTexture(nil, "BACKGROUND", nil, -8)
    t:SetColorTexture(0.02, 0.07, 0.16, 0.9)
    t:SetPoint("CENTER")
    local size = math.min(b:GetWidth() or 31, b:GetHeight() or 31) * 0.72
    t:SetSize(size, size)
    local e = b:CreateTexture(nil, "BACKGROUND", nil, -7)
    e:SetColorTexture(ns.Style.Color("edge"))
    e:SetPoint("TOPLEFT", t, "TOPLEFT", -1, 1)
    e:SetPoint("BOTTOMRIGHT", t, "BOTTOMRIGHT", 1, -1)
    e:SetDrawLayer("BACKGROUND", -8)
    t:SetDrawLayer("BACKGROUND", -7)
    b.fxiTile = t
  end
end

local function IsButton(f)
  local ok, kind = pcall(f.GetObjectType, f)
  return ok and (kind == "Button" or kind == "CheckButton")
end

local function Skip(b)
  local cluster = MinimapCluster
  if b.fxiOurs then return true end
  if cluster and (b == rawget(cluster, "ZoneTextButton")) then return true end
  if b == _G.MinimapZoneTextButton or b == _G.TimeManagerClockButton then return true end
  if b == rawget(Minimap, "ZoomIn") or b == rawget(Minimap, "ZoomOut") then return true end
  for _, junk in ipairs({ "ExpansionLandingPageMinimapButton", "GarrisonLandingPageMinimapButton" }) do
    if b == _G[junk] then return true end
  end
  local w = b:GetWidth() or 0
  return w < 10 or w > 48
end

local Layout

local function Take(b, anyKind)
  if type(b) ~= "table" or buttons[b] or not b.GetObjectType then return end
  if not anyKind and (not IsButton(b) or Skip(b)) then return end
  buttons[b] = true
  if b.RegisterForDrag then pcall(b.RegisterForDrag, b) end   -- no drag
  pcall(Square, b)
  hooksecurefunc(b, "SetPoint", function() if not placing then Layout() end end)
  b:HookScript("OnShow", function() Layout() end)
  b:HookScript("OnHide", function() Layout() end)
end

local function Collect()
  for _, root in ipairs({ Minimap, MinimapCluster, _G.MinimapBackdrop }) do
    if type(root) == "table" and root.GetChildren then
      for _, child in ipairs({ root:GetChildren() }) do Take(child) end
    end
  end
  if _G.GameTimeFrame then Take(_G.GameTimeFrame) end
  -- Blizzard's tracking (magnifier) and mail icons sit in small holder frames.
  local cluster = MinimapCluster
  if cluster then
    local tracking = rawget(cluster, "Tracking") or _G.MiniMapTracking
    if type(tracking) == "table" and (tracking.GetWidth and (tracking:GetWidth() or 0) >= 10) then Take(tracking, true) end
  end
  if type(_G.MiniMapMailFrame) == "table" then Take(_G.MiniMapMailFrame, true) end
  -- LibDBIcon keeps its buttons in a list; some addons parent them elsewhere.
  local lib = LibStub and LibStub("LibDBIcon-1.0", true)
  if lib and type(lib.objects) == "table" then
    for _, b in pairs(lib.objects) do if type(b) == "table" then Take(b) end end
  end
end

Layout = function()
  if not edge or placing then return end
  placing = true
  local list = {}
  for b in pairs(buttons) do
    if b:IsShown() then list[#list + 1] = b end
  end
  table.sort(list, function(a, b) return (a:GetName() or "~") < (b:GetName() or "~") end)
  -- Down the left edge, unless the map is against the left of the screen.
  local left = edge:GetLeft()
  local onRight = left ~= nil and left < SLOT + GAP * 2
  local room = math.floor(((edge:GetHeight() or 150) + GAP) / (SLOT + GAP))
  for i, b in ipairs(list) do
    local w = math.max(b:GetWidth() or SLOT, b:GetHeight() or SLOT, 1)
    local scale = SLOT / w
    pcall(b.SetScale, b, scale)
    pcall(b.ClearAllPoints, b)
    if i <= room then
      local y = -((i - 1) * (SLOT + GAP)) / scale
      if onRight then
        pcall(b.SetPoint, b, "TOPLEFT", edge, "TOPRIGHT", GAP / scale, y)
      else
        pcall(b.SetPoint, b, "TOPRIGHT", edge, "TOPLEFT", -GAP / scale, y)
      end
    else
      -- The rest in a row under the zone strip.
      local x = ((i - room - 1) * (SLOT + GAP)) / scale
      local under = strip or edge
      pcall(b.SetPoint, b, "TOPLEFT", under, "BOTTOMLEFT", x, -GAP / scale)
    end
  end
  placing = false
end

function M.CollectButtons()
  if not edge then return end
  Collect()
  Layout()
end

-- For /fxi check and /fxi map.
function M.ButtonCount()
  if not edge then return "off" end
  local n, shown = 0, 0
  for b in pairs(buttons) do
    n = n + 1
    if b:IsShown() then shown = shown + 1 end
  end
  return ("%d on the map edge (%d shown)"):format(n, shown)
end

---------------------------------------------------------------------------
-- The strip under the map: zone (coloured like the game's PvP colours),
-- your coordinates, and the clock. Click the zone for the world map and the
-- clock for Blizzard's clock options; both hand the click to Blizzard's own
-- (now invisible) buttons, so nothing taints.
---------------------------------------------------------------------------
local PVP = {
  sanctuary = { 0.41, 0.8, 0.94 }, friendly = { 0.1, 1, 0.1 }, hostile = { 1, 0.1, 0.1 },
  contested = { 1, 0.7, 0 }, arena = { 1, 0.1, 0.1 }, combat = { 1, 0.1, 0.1 },
}

local function ZoneColor()
  local fn = (C_PvP and C_PvP.GetZonePVPInfo) or GetZonePVPInfo
  local ok, kind = pcall(fn or function() end)
  local c = ok and type(kind) == "string" and PVP[kind]
  if c then return c[1], c[2], c[3] end
  return ns.Style.Color("title")
end

local function Coords()
  if not (C_Map and C_Map.GetBestMapForUnit and C_Map.GetPlayerMapPosition) then return nil end
  local ok, id = pcall(C_Map.GetBestMapForUnit, "player")
  if not ok or not ns.Readable(id) or not id then return nil end
  local ok2, pos = pcall(C_Map.GetPlayerMapPosition, id, "player")
  if not ok2 or not pos or not pos.GetXY then return nil end
  local x, y = pos:GetXY()
  if not ns.Readable(x) or not x or (x == 0 and y == 0) then return nil end
  return ("%.1f, %.1f"):format(x * 100, y * 100)
end

local function Clock()
  if GameTime_GetTime then
    local ok, t = pcall(GameTime_GetTime, false)
    if ok and type(t) == "string" then return t end
  end
  return date("%H:%M")
end

local function ClickZone(parent, target)
  local b = CreateFrame("Button", nil, parent, "SecureActionButtonTemplate")
  b.fxiOurs = true
  b:RegisterForClicks("AnyUp", "AnyDown")
  if type(target) == "table" and target.Click then
    b:SetAttribute("type", "click")
    b:SetAttribute("clickbutton", target)
    b:SetAttribute("useOnKeyDown", false)
  end
  local hl = b:CreateTexture(nil, "HIGHLIGHT")
  hl:SetAllPoints()
  hl:SetColorTexture(0.47, 0.77, 0.93, 0.15)
  return b
end

local function BuildStrip(back)
  local cluster = MinimapCluster
  local zoneBtn = cluster and (rawget(cluster, "ZoneTextButton") or _G.MinimapZoneTextButton)
  local clockBtn = _G.TimeManagerClockButton

  local s = CreateFrame("Frame", "ForeverXIMapStrip", back)
  s.fxiOurs = true
  s:SetPoint("TOPLEFT", back, "BOTTOMLEFT", 0, -2)
  s:SetPoint("TOPRIGHT", back, "BOTTOMRIGHT", 0, -2)
  s:SetHeight(18)
  ns.Style.Panel(s, 0.92)

  s.clock = ns.Style.Text(s, 11)
  s.clock:SetPoint("RIGHT", s, "RIGHT", -6, 0)
  s.coords = ns.Style.Text(s, 10)
  s.coords:SetTextColor(0.8, 0.84, 0.92)
  s.coords:SetPoint("RIGHT", s.clock, "LEFT", -8, 0)
  s.zone = ns.Style.Text(s, 11)
  s.zone:SetPoint("LEFT", s, "LEFT", 6, 0)
  s.zone:SetPoint("RIGHT", s.coords, "LEFT", -6, 0)
  s.zone:SetJustifyH("LEFT")
  if s.zone.SetWordWrap then s.zone:SetWordWrap(false) end

  -- Click areas over the zone and the clock.
  local z = ClickZone(s, zoneBtn)
  z:SetPoint("TOPLEFT", s, "TOPLEFT")
  z:SetPoint("BOTTOMRIGHT", s.coords, "BOTTOMLEFT", 0, -3)
  z:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
    GameTooltip:AddLine(GetZoneText and GetZoneText() or "", ZoneColor())
    local sub = GetSubZoneText and GetSubZoneText()
    if sub and sub ~= "" then GameTooltip:AddLine(sub, 1, 1, 1) end
    GameTooltip:AddLine("Click for the world map.", 0.6, 0.6, 0.6)
    GameTooltip:Show()
  end)
  z:SetScript("OnLeave", function() GameTooltip:Hide() end)
  local c = ClickZone(s, clockBtn)
  c:SetPoint("TOPLEFT", s.clock, "TOPLEFT", -3, 3)
  c:SetPoint("BOTTOMRIGHT", s, "BOTTOMRIGHT")
  c:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
    GameTooltip:AddLine("Clock", ns.Style.Color("title"))
    GameTooltip:AddDoubleLine("Local time", date("%H:%M"), 1, 1, 1, 1, 1, 1)
    if GetGameTime then
      local h, m = GetGameTime()
      GameTooltip:AddDoubleLine("Realm time", ("%02d:%02d"):format(h, m), 1, 1, 1, 1, 1, 1)
    end
    GameTooltip:AddLine("Click for clock options.", 0.6, 0.6, 0.6)
    GameTooltip:Show()
  end)
  c:SetScript("OnLeave", function() GameTooltip:Hide() end)

  -- Blizzard's zone text and clock: faded and off the mouse (ours take the clicks).
  for _, f in ipairs({ zoneBtn, clockBtn }) do
    if type(f) == "table" then
      Fade(f)
      if f.EnableMouse then pcall(f.EnableMouse, f, false) end
    end
  end

  local function Update()
    s.zone:SetText(GetMinimapZoneText and GetMinimapZoneText() or "")
    s.zone:SetTextColor(ZoneColor())
    s.coords:SetText(ns.db.map.coords and Coords() or "")
    s.clock:SetText(Clock())
  end
  s:RegisterEvent("ZONE_CHANGED")
  s:RegisterEvent("ZONE_CHANGED_INDOORS")
  s:RegisterEvent("ZONE_CHANGED_NEW_AREA")
  s:RegisterEvent("PLAYER_ENTERING_WORLD")
  s:SetScript("OnEvent", Update)
  local acc = 0
  s:SetScript("OnUpdate", function(_, dt)
    acc = acc + dt
    if acc < 0.25 then return end
    acc = 0
    Update()
  end)
  Update()
  return s
end

function M:Init()
  if not ns.db.map.skin or type(Minimap) ~= "table" then return end
  local map = Minimap

  if ns.db.map.square and map.SetMaskTexture then
    pcall(map.SetMaskTexture, map, "Interface\\Buttons\\WHITE8X8")
    GetMinimapShape = SquareShape
  end
  for _, name in ipairs(ART_NAMES) do Fade(_G[name]) end
  local cluster = MinimapCluster
  for _, key in ipairs(ART_KEYS) do
    if cluster then Fade(cluster[key]) end
    if key ~= "Background" then Fade(map[key]) end
  end

  -- The window: a plain frame behind the map.
  local back = CreateFrame("Frame", nil, map)
  back:SetFrameLevel(math.max(0, map:GetFrameLevel() - 1))
  back:SetPoint("TOPLEFT", map, "TOPLEFT", -4, 4)
  back:SetPoint("BOTTOMRIGHT", map, "BOTTOMRIGHT", 4, -4)
  ns.Style.Panel(back, 0.95)
  self.back = back

  strip = BuildStrip(back)
  self.strip = strip

  if ns.db.map.buttonColumn then
    edge = back
    M.CollectButtons()
    -- Addons make their buttons over the first seconds after login.
    for _, t in ipairs({ 1, 3, 8, 15 }) do C_Timer.After(t, M.CollectButtons) end
  end
end

-- For /fxi check: is the built-in damage meter here (MeterSkin skins it).
function M.DamageMeterNames()
  local m = ns.modules.MeterSkin
  return m and m.Describe and m.Describe() or "none found"
end
