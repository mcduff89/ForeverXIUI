-- Target bar (XIUI style): one long slim bar, the target's name above it on
-- the left and HP% on the right. The target's cast bar sits under it.
-- Not secure: it shows and hides with your target, in or out of combat.
local _, ns = ...

local M = ns.AddModule("TargetBar")

local W, W_COMPACT, H = 390, 300, 16

-- Threat colour for the bar, or nil to keep XIUI's pink.
-- UnitThreatSituation: 0 not tanking, lower threat; 1 not tanking, higher
-- than the tank; 2 tanking but someone is higher; 3 tanking securely.
-- nil means the target isn't fighting you. A secret answer is skipped.
local function IsTank()
  if ns.db.target.alwaysTank then return true end
  local ok, role = pcall(UnitGroupRolesAssigned, "player")
  return ok and ns.Readable(role) and role == "TANK"
end

local function ThreatColorKey()
  if not ns.db.target.threatColors or not UnitThreatSituation then return nil end
  local ok, status = pcall(UnitThreatSituation, "player", "target")
  if not ok or type(status) ~= "number" or not ns.Readable(status) then return nil end
  if IsTank() then
    -- green = you have it, yellow = losing it, red = lost it
    if status == 3 then return "threatGood" end
    if status == 2 then return "threatWarn" end
    return "threatBad"
  end
  -- green = safe, yellow = careful, red = it's on you
  if status == 0 then return "threatGood" end
  if status == 1 then return "threatWarn" end
  return "threatBad"
end
M.ThreatColorKey = ThreatColorKey

local function Update(f)
  if not UnitExists("target") then
    f:Hide()
    return
  end
  f:Show()
  ns.Values.Name(f.name, "target")
  ns.Values.Health(f.hp, f.pct, "target", "percent", false)
  f.hp:SetStatusBarColor(ns.Style.Color(ThreatColorKey() or ns.Style.HealthKey("hpTarget")))
  local dead = ns.Values.IsDead("target")
  if dead then f.pct:SetText("Dead") end
end

local function Layout(f)
  local w = ns.db.compact and W_COMPACT or W
  f:SetSize(w, H + 18)
  f.hp:SetSize(w, H)
end

function M:Init()
  if ns.db.modules.target then
    local f = CreateFrame("Frame", "ForeverXITargetBar", UIParent)
    f.hp = ns.Style.Bar(f, W, H, "hpTarget")
    f.hp:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 0, 2)
    f.hp:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", 0, 2)

    f.name = ns.Style.Text(f, 13)
    f.name:SetPoint("BOTTOMLEFT", f.hp, "TOPLEFT", 4, 2)
    f.name:SetJustifyH("LEFT")
    f.name:SetWordWrap(false)
    f.pct = ns.Style.Text(f, 12)
    f.pct:SetPoint("BOTTOMRIGHT", f.hp, "TOPRIGHT", -4, 2)
    f.pct:SetJustifyH("RIGHT")
    f.pct:SetTextColor(ns.Style.Color("hpText"))
    f.name:SetPoint("RIGHT", f.pct, "LEFT", -8, 0)
    Layout(f)

    f:RegisterEvent("PLAYER_TARGET_CHANGED")
    f:RegisterEvent("PLAYER_ENTERING_WORLD")
    for _, e in ipairs({ "UNIT_THREAT_SITUATION_UPDATE", "UNIT_THREAT_LIST_UPDATE", "PLAYER_REGEN_ENABLED",
      "PLAYER_REGEN_DISABLED", "PLAYER_ROLES_ASSIGNED" }) do
      pcall(f.RegisterEvent, f, e)
    end
    for _, e in ipairs({ "UNIT_HEALTH", "UNIT_MAXHEALTH", "UNIT_NAME_UPDATE", "UNIT_FLAGS" }) do
      pcall(f.RegisterUnitEvent, f, e, "target")
    end
    f:SetScript("OnEvent", function(self) if not self.previewing then Update(self) end end)
    Update(f)

    self.frame = f
    ns.AddRoot(f, "target")
    ns.Movers.Register("target", "Target bar", f, { "BOTTOM", "BOTTOM", 0, 360 })
  end

  if ns.db.modules.targetCast then
    local c = ns.CastBar.Create("ForeverXITargetCast", "target", 300, 13, true)
    self.cast = c
    ns.AddRoot(c, "targetCast")
    ns.Movers.Register("targetCast", "Target cast bar", c, { "BOTTOM", "BOTTOM", 0, 340 })
  end
end

function M:Relayout()
  if self.frame then Layout(self.frame) end
end

-- /fxi move shows a pretend target so the bar can be placed.
function M:Preview(on)
  local f = self.frame
  if f then
    f.previewing = on and true or nil
    if on then
      f.name:SetText("Target Name")
      f.pct:SetText("62%")
      f.hp:SetMinMaxValues(0, 100)
      f.hp:SetValue(62)
      f:Show()
    else
      Update(f)
    end
  end
  if self.cast then ns.CastBar.Preview(self.cast, on) end
end
