-- The minimap in the XI look: a square map in a navy window with a steel
-- edge, Blizzard's round border art faded, the zone name on a navy strip
-- above it, and every button that sat around the map (Blizzard's and the
-- addons' LibDBIcon ones) lined up in a column down its left side.
--
-- Only looks: the map's mask texture and the alpha of Blizzard's art. The
-- minimap cluster is an Edit Mode frame and is never moved or re-parented;
-- place it in Edit Mode and the window follows. A /reload is needed to go
-- back to the round map.
local _, ns = ...

local M = ns.AddModule("MapSkin")

-- Round decoration on the minimap, by name or by key on the cluster/map.
local ART_NAMES = { "MinimapBorder", "MinimapBorderTop", "MinimapCompassTexture", "MinimapBackdrop",
  "MinimapNorthTag" }
local ART_KEYS = { "BorderTop", "Border", "Background" }

local faded = {}
local function KeepFaded(region)
  if faded[region] and region:GetAlpha() > 0 then region:SetAlpha(0) end
end

local function Fade(region)
  if type(region) ~= "table" or not region.SetAlpha then return end
  region:SetAlpha(0)
  if not faded[region] then
    faded[region] = true
    hooksecurefunc(region, "SetAlpha", KeepFaded)
  end
end

-- Addons that put buttons around the map (LibDBIcon) ask this to know where
-- the edge is.
local function SquareShape() return "SQUARE" end

---------------------------------------------------------------------------
-- The button column. Buttons are only re-anchored (never re-parented), and
-- dragging them is turned off so they stay in line. When an addon puts its
-- button back (LibDBIcon does on every update), the column takes it again.
---------------------------------------------------------------------------
local BTN_GAP, COL_PAD = 2, 3
local column, buttons, placing = nil, {}, false

local function IsButton(f)
  local ok, kind = pcall(f.GetObjectType, f)
  return ok and (kind == "Button" or kind == "CheckButton")
end

local function Skip(b)
  local cluster = MinimapCluster
  if b.fxiOurs then return true end
  if cluster and (b == rawget(cluster, "ZoneTextButton")) then return true end
  if b == _G.MinimapZoneTextButton or b == _G.TimeManagerClockButton then return true end
  if b == rawget(Minimap, "ZoomIn") or b == rawget(Minimap, "ZoomOut") then return true end
  for _, junk in ipairs({ "ExpansionLandingPageMinimapButton", "GarrisonLandingPageMinimapButton" }) do
    if b == _G[junk] then return true end
  end
  local w = b:GetWidth() or 0
  return w < 10 or w > 48
end

local Layout

local function Take(b)
  if buttons[b] or not IsButton(b) or Skip(b) then return end
  buttons[b] = true
  if b.RegisterForDrag then pcall(b.RegisterForDrag, b) end   -- no drag
  hooksecurefunc(b, "SetPoint", function() if not placing then Layout() end end)
  b:HookScript("OnShow", function() Layout() end)
  b:HookScript("OnHide", function() Layout() end)
end

local function Collect()
  for _, root in ipairs({ Minimap, MinimapCluster, _G.MinimapBackdrop }) do
    if type(root) == "table" and root.GetChildren then
      for _, child in ipairs({ root:GetChildren() }) do Take(child) end
    end
  end
  if _G.GameTimeFrame then Take(_G.GameTimeFrame) end
  -- LibDBIcon keeps its buttons in a list; some addons parent them elsewhere.
  local lib = LibStub and LibStub("LibDBIcon-1.0", true)
  if lib and type(lib.objects) == "table" then
    for _, b in pairs(lib.objects) do if type(b) == "table" then Take(b) end end
  end
end

Layout = function()
  if not column or placing then return end
  placing = true
  local list = {}
  for b in pairs(buttons) do
    if b:IsShown() then list[#list + 1] = b end
  end
  table.sort(list, function(a, b) return (a:GetName() or "~") < (b:GetName() or "~") end)
  local maxH = math.max(60, (Minimap:GetHeight() or 140) + 8)
  local x, y, colW, cols = 0, 0, 0, 1
  for _, b in ipairs(list) do
    local bw, bh = b:GetWidth() or 24, b:GetHeight() or 24
    if y > 0 and y + bh > maxH - COL_PAD * 2 then   -- wrap into another column, further out
      x = x + colW + BTN_GAP
      y, colW, cols = 0, 0, cols + 1
    end
    pcall(b.ClearAllPoints, b)
    pcall(b.SetPoint, b, "TOPRIGHT", column, "TOPRIGHT", -(COL_PAD + x), -(COL_PAD + y))
    y = y + bh + BTN_GAP
    colW = math.max(colW, bw)
  end
  column:SetWidth(x + colW + COL_PAD * 2)
  column:SetShown(#list > 0)
  placing = false
end

function M.CollectButtons()
  if not column then return end
  Collect()
  Layout()
end

-- For /fxi check and /fxi map.
function M.ButtonCount()
  if not column then return "column off" end
  local n, shown = 0, 0
  for b in pairs(buttons) do
    n = n + 1
    if b:IsShown() then shown = shown + 1 end
  end
  return ("%d in the column (%d shown)"):format(n, shown)
end

function M.SetColumn(f) column = f end


function M:Init()
  if not ns.db.map.skin or type(Minimap) ~= "table" then return end
  local map = Minimap

  if ns.db.map.square and map.SetMaskTexture then
    pcall(map.SetMaskTexture, map, "Interface\\Buttons\\WHITE8X8")
    GetMinimapShape = SquareShape
  end
  for _, name in ipairs(ART_NAMES) do Fade(_G[name]) end
  local cluster = MinimapCluster
  for _, key in ipairs(ART_KEYS) do
    if cluster then Fade(cluster[key]) end
    if key ~= "Background" then Fade(map[key]) end
  end

  -- The window: a plain frame behind the map.
  local back = CreateFrame("Frame", nil, map)
  back:SetFrameLevel(math.max(0, map:GetFrameLevel() - 1))
  back:SetPoint("TOPLEFT", map, "TOPLEFT", -4, 4)
  back:SetPoint("BOTTOMRIGHT", map, "BOTTOMRIGHT", 4, -4)
  ns.Style.Panel(back, 0.95)
  self.back = back

  -- Zone name strip, behind Blizzard's own zone text button.
  -- It covers the art it replaces (the cluster's top border), else the button.
  local zone = cluster and (cluster.ZoneTextButton or MinimapZoneTextButton)
  local spot = cluster and cluster.BorderTop
  if type(spot) ~= "table" or not spot.GetCenter then spot = zone end
  if type(spot) == "table" and spot.GetCenter then
    local strip = CreateFrame("Frame", nil, cluster)
    local level = (zone and zone.GetFrameLevel and zone:GetFrameLevel()) or cluster:GetFrameLevel()
    strip:SetFrameLevel(math.max(0, level - 1))
    strip:SetAllPoints(spot)
    ns.Style.Panel(strip, 0.9)
    self.strip = strip
  end

  if ns.db.map.buttonColumn then
    local col = CreateFrame("Frame", nil, back)
    col.fxiOurs = true
    col:SetPoint("TOPRIGHT", back, "TOPLEFT", -4, 0)
    col:SetPoint("BOTTOMRIGHT", back, "BOTTOMLEFT", -4, 0)
    col:SetWidth(30)
    ns.Style.Panel(col, 0.95)
    col:Hide()
    M.SetColumn(col)
    M.CollectButtons()
    -- Addons make their buttons over the first seconds after login.
    for _, t in ipairs({ 1, 3, 8, 15 }) do C_Timer.After(t, M.CollectButtons) end
  end
end

-- For /fxi check: is the built-in damage meter here (MeterSkin skins it).
function M.DamageMeterNames()
  local m = ns.modules.MeterSkin
  return m and m.Describe and m.Describe() or "none found"
end
